---
name: umiguri-charter
description: Analyze a song/audio file and create a playable CHUNITHM chart draft for the UMIGURI simulator through the Margrete chart editor and Margrete RPC. Use when the user invokes /chart-umiguri or asks to turn music into a UMIGURI-playable CHUNITHM chart edited in Margrete from audio, metadata, desired difficulty, chart style, song feeling, osu reference files, or extra charting instructions.
---

# UMIGURI Charter

Create a CHUNITHM chart draft for UMIGURI, edited through Margrete, by analyzing the music first and then generating Python `margrete_rpc` notes for review or live push.

## Core Workflow

For `/chart-umiguri`, gather or infer:

- audio file path
- additional song metadata
- desired difficulty
- chart style
- song feeling
- extra instructions
- optional `.osu` chart file for timing and placement reference

Read `references/workflow.md` before running tools. Read `references/charting-guidelines.md` before making charting decisions or editing generated note patterns.

## Analysis

Use `scripts/analyze_music.py` to produce reusable artifacts:

```powershell
python examples\agent\umiguri-charter\scripts\analyze_music.py --file path\to\song.mp3 --desired-difficulty "MASTER 14" --chart-style "technical"
```

If the user provides trusted BPM, offset, or timing-map information, pass it to analysis instead of relying only on detection.

Always inspect the generated JSON and images before charting. Treat BPM, downbeat, and section labels as hypotheses; correct them when the audio evidence or metadata disagrees.

If the user provides an osu chart file, analyze it as reference material:

```powershell
python examples\agent\umiguri-charter\scripts\analyze_osu_reference.py --osu-file path\to\reference.osu
```

Use osu timing/object placement to inform rhythm density, phrasing, and anchor timings. Do not copy it blindly into CHUNITHM patterns.

## Chart Drafting

Use `scripts/draft_umiguri_chart.py` for a deterministic first pass from an analysis folder:

```powershell
python examples\agent\umiguri-charter\scripts\draft_umiguri_chart.py --analysis-dir examples\agent\music\_analysis\SongName --difficulty "MASTER 14" --style "technical, readable" --osu-reference-dir examples\agent\music\_analysis_osu\ReferenceName
```

The script is dry-run by default and writes `draft_chart_report.json`. Use `--push` only when the user wants to create or replace notes in an open Margrete session.

```powershell
python examples\agent\umiguri-charter\scripts\draft_umiguri_chart.py --analysis-dir examples\agent\music\_analysis\SongName --difficulty "MASTER 14" --style "technical, readable" --push
```

## Authoring Rules

- Prefer a playable draft over a maximal note dump.
- Match important musical accents before filling density.
- Scale density, chords, air, holds, slides, and gimmicks from the user's difficulty and style text.
- Use CHUNITHM labels, numeric levels, and free-form difficulty requests as intent, not exact guarantees.
- If the generated draft is crude, edit the Python pattern logic or add hand-authored note passes before pushing.
- Do not overwrite the chart currently open in Margrete unless the user asked for replacement or approved it.

## Outputs

Return the analysis folder path, the draft report path, whether anything was pushed to Margrete, and the major chart assumptions: BPM, first beat, difficulty interpretation, style interpretation, and known weak points.
