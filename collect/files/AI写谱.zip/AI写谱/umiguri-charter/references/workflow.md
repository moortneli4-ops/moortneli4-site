# Workflow

Use this flow for `/chart-umiguri` requests.

1. Collect inputs:
   - song/audio file
   - optional metadata: title, artist, BPM if known, offset if known, source, notes
   - desired difficulty: CHUNITHM label, numeric level, or free-form target
   - chart style
   - song feeling and extra instructions
   - optional `.osu` chart file for timing and placement reference
2. Run `scripts/analyze_music.py`.
3. If an osu chart is provided, run `scripts/analyze_osu_reference.py`.
4. Inspect `analysis.json`, `beat_grid.json`, `sections.json`, `bar_features.json`, waveform, spectrogram, and any osu reference artifacts.
5. If BPM or offset is obviously wrong, rerun analysis with `--bpm` and `--offset`.
6. Use `scripts/draft_umiguri_chart.py --analysis-dir ...` for a deterministic first pass.
7. Review the draft report and adjust the generated Python or pattern decisions before pushing.
8. Push to Margrete only when the user asked for live chart creation or confirmed Margrete is open.

Preferred commands from the repo root:

```powershell
python examples\agent\umiguri-charter\scripts\analyze_music.py --file path\to\song.mp3 --desired-difficulty "MASTER 14" --chart-style "technical, readable"
python examples\agent\umiguri-charter\scripts\analyze_osu_reference.py --osu-file path\to\reference.osu
python examples\agent\umiguri-charter\scripts\draft_umiguri_chart.py --analysis-dir examples\agent\music\_analysis\SongName --difficulty "MASTER 14" --style "technical, readable"
python examples\agent\umiguri-charter\scripts\draft_umiguri_chart.py --analysis-dir examples\agent\music\_analysis\SongName --difficulty "MASTER 14" --style "technical, readable" --push
```

Analysis artifacts:

- `analysis.json`: top-level summary, probe metadata, BPM candidates, chart request fields.
- `beat_grid.json`: BPM, first beat time, confidence, beat positions.
- `onsets.json`: accent candidates with time, score, family, and spectral bands.
- `bar_features.json`: per-bar energy, density, bass, brightness.
- `sections.json`: suggested phrases.
- `waveform.png` and `spectrogram.png`: fast visual checks.

osu reference artifacts:

- `osu_reference.json`: metadata, timing points, density, rhythm summary.
- `osu_hitobjects.json` / `.csv`: object time, lane, duration, chord, and grid fit.
- `osu_bar_features.json` / `.csv`: bar-level object density and lane usage.

Treat analysis output as evidence, not ground truth. Audio-only BPM and downbeat detection can be wrong on intros, rubato, half-time sections, silence, or dense mixed masters.
