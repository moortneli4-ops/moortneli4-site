# Charting Guidelines

## Priorities

1. Preserve timing clarity before density.
2. Put important musical events on readable notes.
3. Make difficulty through pattern design, not only note count.
4. Keep hand motion plausible across the 16-lane field.
5. Use air and slide gestures where the song supports them.

## Difficulty Interpretation

- `BASIC`: sparse quarter/eighth rhythm, wide notes, little or no air.
- `ADVANCED`: more eighth rhythm, simple holds/slides, occasional air.
- `EXPERT`: sixteenth accents, controlled chords, visible melody tracing.
- `MASTER`: denser rhythm, technical alternation, more air/slide vocabulary.
- `ULTIMA`: peak density and gimmicks, but still match the music and avoid random noise.
- Numeric levels: map higher levels to lower spacing, more chords, more air, and more long-note complexity.
- Free-form targets such as "hardest chart in the world" mean maximize intensity, but still keep the draft inspectable and mechanically coherent.

## CHUNITHM Patterns for UMIGURI

- Use taps for kicks, bass anchors, and stable pulse.
- Use flicks for bright percussion, cuts, risers, and obvious directional gestures.
- Use ex-taps for emphasized melody hits or high-value accents.
- Use holds for sustained vocals, pads, long guitar/synth tones, and stable phrase starts.
- Use slides for melodic movement, arpeggios, sweeps, and flowing phrase contours.
- Use attached air for jumps, upward gestures, vocal peaks, and bright accent responses.
- Use air-crush sparingly for effect-like passages, lasers, strong electronic texture, or gimmick sections.

## Using osu References

- Use osu timing points to confirm BPM, offset, phrase length, and dense rhythmic passages.
- Use hitobject density as a placement reference, not a CHUNITHM pattern source.
- Translate repeated osu lanes into CHUNITHM hand motion only when it remains readable on the 16-lane field.
- Preserve memorable anchor timings from a good reference chart, but redesign gestures with CHUNITHM note vocabulary.

## Review Checklist

- BPM and first beat align with clear downbeats.
- Sections roughly match intro/build/drop/chorus/break/outro.
- The first draft leaves room for manual authoring; it should not pretend to be final.
- Dense parts have recovery moments.
- Chords do not appear only because two unrelated sounds overlap.
- Long notes do not cover important tap rhythms unless that is the intended feel.
- Air notes are meaningful gestures, not random decoration.
