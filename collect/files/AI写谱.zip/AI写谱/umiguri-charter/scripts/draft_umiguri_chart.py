from __future__ import annotations

# ruff: noqa: E402
import argparse
import json
import math
import re
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any


def add_repo_src_to_path() -> None:
    for parent in Path(__file__).resolve().parents:
        src = parent / "src"
        if (src / "margrete_rpc").is_dir():
            sys.path.insert(0, str(src))
            return


add_repo_src_to_path()

from margrete_rpc import Margrete
from margrete_rpc.chart import TICK_RESOLUTION, ChartNote
from margrete_rpc.chart.events import BeatEvent, BpmEvent
from margrete_rpc.chart.notes import (
    Air,
    AirCrush,
    AirDirection,
    ColorValue,
    Extap,
    ExtapDirection,
    Flick,
    FlickDirection,
    Hold,
    Slide,
    Tap,
)

QUARTER_TICK = TICK_RESOLUTION // 4
FIELD_WIDTH = 16


@dataclass(frozen=True)
class DraftProfile:
    intensity: float
    min_gap_ticks: int
    max_notes_per_second: float
    chord_rate: float
    hold_rate: float
    slide_rate: float
    air_rate: float
    aircrush_rate: float
    quantize_ticks: int


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


def parse_level(value: str | None) -> float:
    if not value:
        return 0.62
    text = value.lower()
    if any(word in text for word in ("hardest", "world", "impossible", "insane")):
        return 1.0
    labels = {
        "basic": 0.18,
        "advanced": 0.34,
        "expert": 0.58,
        "master": 0.78,
        "ultima": 0.9,
    }
    for label, intensity in labels.items():
        if label in text:
            return intensity
    match = re.search(r"(\d+(?:\.\d+)?)(\+?)", text)
    if not match:
        return 0.62
    level = float(match.group(1)) + (0.6 if match.group(2) else 0.0)
    return min(1.0, max(0.12, (level - 3.0) / 12.5))


def style_bias(style: str | None, feeling: str | None, extra: str | None) -> dict[str, float]:
    text = " ".join(item for item in (style, feeling, extra) if item).lower()
    bias = {
        "chord": 1.0,
        "hold": 1.0,
        "slide": 1.0,
        "air": 1.0,
        "aircrush": 1.0,
        "density": 1.0,
    }
    if any(word in text for word in ("technical", "tech", "jack", "trill", "dense")):
        bias["density"] *= 1.25
        bias["chord"] *= 1.2
    if any(word in text for word in ("readable", "arcade", "fair", "clean")):
        bias["density"] *= 0.86
        bias["chord"] *= 0.85
    if any(word in text for word in ("hold", "sustain", "long", "vocal", "lyrical")):
        bias["hold"] *= 1.55
    if any(word in text for word in ("slide", "sweep", "flow", "melodic")):
        bias["slide"] *= 1.6
    if any(word in text for word in ("air", "jump", "sky")):
        bias["air"] *= 1.7
    if any(word in text for word in ("gimmick", "effect", "laser", "crush")):
        bias["aircrush"] *= 1.75
        bias["slide"] *= 1.25
    return bias


def make_profile(
    difficulty: str | None, style: str | None, feeling: str | None, extra: str | None
) -> DraftProfile:
    intensity = parse_level(difficulty)
    bias = style_bias(style, feeling, extra)
    min_gap_beats = 0.55 - 0.42 * intensity
    min_gap_ticks = max(QUARTER_TICK // 16, int(round(QUARTER_TICK * min_gap_beats)))
    max_notes_per_second = (1.25 + 7.25 * intensity) * bias["density"]
    quantize_denominator = (
        4 if intensity < 0.28 else 8 if intensity < 0.48 else 16 if intensity < 0.82 else 32
    )
    return DraftProfile(
        intensity=intensity,
        min_gap_ticks=min_gap_ticks,
        max_notes_per_second=max_notes_per_second,
        chord_rate=min(0.55, (0.02 + 0.34 * intensity) * bias["chord"]),
        hold_rate=min(0.5, (0.05 + 0.26 * intensity) * bias["hold"]),
        slide_rate=min(0.48, (0.03 + 0.28 * intensity) * bias["slide"]),
        air_rate=min(0.64, (0.03 + 0.4 * intensity) * bias["air"]),
        aircrush_rate=min(0.34, (0.01 + 0.18 * intensity) * bias["aircrush"]),
        quantize_ticks=max(1, QUARTER_TICK // quantize_denominator),
    )


def load_analysis(analysis_dir: Path) -> dict[str, Any]:
    analysis = read_json(analysis_dir / "analysis.json")
    beat_grid = read_json(analysis_dir / "beat_grid.json")
    onsets = read_json(analysis_dir / "onsets.json")
    bars_path = analysis_dir / "bar_features.json"
    sections_path = analysis_dir / "sections.json"
    known_timing_path = analysis_dir / "known_timing_report.json"
    return {
        "analysis": analysis,
        "beat_grid": beat_grid,
        "onsets": onsets,
        "bars": read_json(bars_path) if bars_path.exists() else [],
        "sections": read_json(sections_path) if sections_path.exists() else [],
        "known_timing": read_json(known_timing_path) if known_timing_path.exists() else None,
    }


def quantize_tick(tick: int, quantum: int) -> int:
    return max(0, int(round(tick / quantum) * quantum))


def onset_tick(
    event: dict[str, Any], first_beat_time: float, bpm: float, profile: DraftProfile
) -> int:
    seconds_per_beat = 60.0 / bpm
    beat_position = (float(event["time"]) - first_beat_time) / seconds_per_beat
    raw_tick = int(round(beat_position * QUARTER_TICK))
    return quantize_tick(raw_tick, profile.quantize_ticks)


def pick_onsets(
    onsets: list[dict[str, Any]],
    first_beat_time: float,
    bpm: float,
    duration: float,
    profile: DraftProfile,
    limit_bars: int | None,
) -> list[tuple[int, dict[str, Any]]]:
    minimum_score = max(0.12, 0.62 - 0.42 * profile.intensity)
    max_count = int(max(8, duration * profile.max_notes_per_second))
    limit_tick = None
    if limit_bars is not None:
        limit_tick = limit_bars * QUARTER_TICK * 4
    candidates = []
    for event in onsets:
        if float(event.get("score", 0.0)) < minimum_score:
            continue
        tick = onset_tick(event, first_beat_time, bpm, profile)
        if tick < 0:
            continue
        if limit_tick is not None and tick >= limit_tick:
            continue
        candidates.append((tick, event))
    candidates.sort(key=lambda item: (item[0], -float(item[1].get("score", 0.0))))
    selected: list[tuple[int, dict[str, Any]]] = []
    occupied: set[int] = set()
    for tick, event in candidates:
        if tick in occupied:
            continue
        if selected and tick - selected[-1][0] < profile.min_gap_ticks:
            if float(event.get("score", 0.0)) <= float(selected[-1][1].get("score", 0.0)):
                continue
            selected[-1] = (tick, event)
        else:
            selected.append((tick, event))
        occupied.add(tick)
        if len(selected) >= max_count:
            break
    return selected


def lane_for(index: int, event: dict[str, Any], profile: DraftProfile) -> tuple[int, int]:
    score = float(event.get("score", 0.0))
    base_width = 2 if profile.intensity >= 0.45 else 3
    if score > 0.82 and profile.intensity < 0.72:
        base_width += 1
    width = min(6, max(1, base_width))
    span = FIELD_WIDTH - width
    sweep = index % 16
    if (index // 16) % 2:
        sweep = 15 - sweep
    x = int(round((sweep / 15.0) * span))
    return x, width


def make_air(tick: int, x: int, width: int, index: int) -> Air:
    directions = [
        AirDirection.UP,
        AirDirection.UP_LEFT,
        AirDirection.UP_RIGHT,
        AirDirection.DOWN_LEFT,
        AirDirection.DOWN_RIGHT,
    ]
    return Air(directions[index % len(directions)], t=tick, x=x, w=width)


def make_slide(tick: int, x: int, width: int, index: int, profile: DraftProfile) -> Slide:
    length = QUARTER_TICK * (1 if profile.intensity < 0.7 else 2)
    target_x = max(0, min(FIELD_WIDTH - width, FIELD_WIDTH - width - x))
    if abs(target_x - x) < 3:
        target_x = (x + 6 + index) % max(1, FIELD_WIDTH - width)
    return Slide(t=tick, x=x, w=width).with_step(t=tick + length, x=target_x, w=width)


def make_hold(tick: int, x: int, width: int, profile: DraftProfile) -> Hold:
    length = QUARTER_TICK * (1 if profile.intensity < 0.55 else 2)
    return Hold(t=tick, x=x, w=width).with_step(t=tick + length, x=x, w=width)


def make_aircrush(tick: int, x: int, width: int, index: int, profile: DraftProfile) -> AirCrush:
    length = QUARTER_TICK * (1 if profile.intensity < 0.78 else 2)
    h = 60 + (index % 5) * 12
    target_x = max(0, min(FIELD_WIDTH - width, x + (-4 if index % 2 else 4)))
    color = [
        ColorValue.SKY,
        ColorValue.BLUE,
        ColorValue.VIOLET,
        ColorValue.PINK,
        ColorValue.YELLOW,
    ][index % 5]
    return AirCrush(t=tick, x=x, w=width, h=h, color=color, gap=(1, 8)).with_ctrl(
        t=tick + length,
        x=target_x,
        w=width,
        h=max(30, min(120, h + (20 if index % 2 else -20))),
    )


def deterministic_pick(index: int, salt: int) -> float:
    value = math.sin((index + 1) * 12.9898 + salt * 78.233) * 43758.5453
    return value - math.floor(value)


def build_notes(
    selected: list[tuple[int, dict[str, Any]]], profile: DraftProfile
) -> list[ChartNote]:
    notes: list[ChartNote] = []
    last_long_end = -1
    for index, (tick, event) in enumerate(selected):
        family = str(event.get("family", "mixed_accent"))
        score = float(event.get("score", 0.0))
        x, width = lane_for(index, event, profile)
        can_long = tick > last_long_end + profile.min_gap_ticks
        if can_long and "melody" in family and deterministic_pick(index, 3) < profile.slide_rate:
            note = make_slide(tick, x, width, index, profile)
            last_long_end = max(last_long_end, tick + QUARTER_TICK)
            notes.append(note)
        elif can_long and deterministic_pick(index, 5) < profile.hold_rate:
            note = make_hold(tick, x, width, profile)
            last_long_end = max(last_long_end, tick + QUARTER_TICK)
            if deterministic_pick(index, 7) < profile.air_rate * 0.45:
                note = note.with_air(make_air(tick + QUARTER_TICK, x, width, index))
            notes.append(note)
        elif can_long and deterministic_pick(index, 9) < profile.aircrush_rate and score > 0.58:
            notes.append(make_aircrush(tick, x, width, index, profile))
            last_long_end = max(last_long_end, tick + QUARTER_TICK)
        elif "hat" in family or "noise" in family:
            direction = FlickDirection.LEFT if index % 2 else FlickDirection.RIGHT
            note = Flick(t=tick, x=x, w=width, dir=direction)
            if deterministic_pick(index, 11) < profile.air_rate:
                note = note.with_air(make_air(tick, x, width, index))
            notes.append(note)
        elif "kick" in family or "bass" in family:
            note = Tap(t=tick, x=x, w=min(width + 1, FIELD_WIDTH - x))
            notes.append(note)
        elif score > 0.72:
            direction = ExtapDirection.UP if index % 3 else ExtapDirection.IN_OUT
            note = Extap(t=tick, x=x, w=width, dir=direction)
            if deterministic_pick(index, 13) < profile.air_rate:
                note = note.with_air(make_air(tick, x, width, index))
            notes.append(note)
        else:
            notes.append(Tap(t=tick, x=x, w=width))
        if deterministic_pick(index, 17) < profile.chord_rate and profile.intensity > 0.48:
            chord_width = max(1, width - 1)
            chord_x = max(0, min(FIELD_WIDTH - chord_width, FIELD_WIDTH - x - chord_width))
            if abs(chord_x - x) >= width + 1:
                notes.append(Tap(t=tick, x=chord_x, w=chord_width))
    notes.sort(key=lambda note: int(note.t))
    return notes


def summarize_notes(notes: list[ChartNote]) -> dict[str, Any]:
    counts = Counter(type(note).__name__ for note in notes)
    return {
        "note_count": len(notes),
        "counts": dict(sorted(counts.items())),
        "first_tick": min((int(note.t) for note in notes), default=0),
        "last_tick": max((int(note.t) for note in notes), default=0),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Draft a UMIGURI-playable CHUNITHM chart edited through Margrete."
    )
    parser.add_argument("--analysis-dir", type=Path, required=True)
    parser.add_argument("--osu-reference-dir", type=Path)
    parser.add_argument("--difficulty")
    parser.add_argument("--style")
    parser.add_argument("--feeling")
    parser.add_argument("--extra-instruction")
    parser.add_argument("--limit-bars", type=int)
    parser.add_argument("--output-report", type=Path)
    parser.add_argument("--push", action="store_true")
    parser.add_argument("--append", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data = load_analysis(args.analysis_dir.resolve())
    analysis = data["analysis"]
    beat_grid = data["beat_grid"]
    bpm = beat_grid.get("bpm") or analysis.get("summary", {}).get("primary_bpm")
    known_timing = data.get("known_timing")
    if bpm is None and known_timing:
        bpm = known_timing.get("known_timing", {}).get("bpm")
    if bpm is None:
        raise SystemExit(
            "Analysis has no BPM. Re-run analyze_music.py with --bpm if detection failed."
        )
    bpm = float(bpm)
    first_beat_time = float(beat_grid.get("first_beat_time", 0.0))
    duration = float(analysis.get("song", {}).get("duration", 0.0))
    difficulty = args.difficulty or analysis.get("chart_request", {}).get("desired_difficulty")
    style = args.style or analysis.get("chart_request", {}).get("chart_style")
    profile = make_profile(difficulty, style, args.feeling, args.extra_instruction)
    selected = pick_onsets(
        data["onsets"],
        first_beat_time,
        bpm,
        duration,
        profile,
        args.limit_bars,
    )
    notes = build_notes(selected, profile)
    report = {
        "source_analysis": str(args.analysis_dir.resolve()),
        "bpm": bpm,
        "first_beat_time": first_beat_time,
        "difficulty": difficulty,
        "style": style,
        "feeling": args.feeling,
        "extra_instruction": args.extra_instruction,
        "osu_reference": str(args.osu_reference_dir.resolve()) if args.osu_reference_dir else None,
        "profile": profile.__dict__,
        "sections": data["sections"]
        or (known_timing or {}).get("audio_sections")
        or (known_timing or {}).get("phrases_4bar"),
        "selected_onsets": len(selected),
        "summary": summarize_notes(notes),
    }
    report_path = args.output_report or (args.analysis_dir.resolve() / "draft_chart_report.json")
    write_json(report_path, report)
    print(json.dumps(report["summary"], indent=2, ensure_ascii=False))
    print(f"Wrote {report_path}")
    if not args.push:
        print("Dry run only. Re-run with --push to replace or append in Margrete.")
        return
    mg = Margrete()
    print(mg.status())
    with mg.open_edit("umiguri chart draft", replace_all=not args.append) as tx:
        tx.chart.events.bpm = [BpmEvent(0, bpm)]
        tx.chart.events.beat = [BeatEvent(0, 4, 4)]
        if args.append:
            tx.chart.notes.extend(notes)
        else:
            tx.chart.notes = notes
    print("Pushed draft chart to Margrete.")


if __name__ == "__main__":
    main()
