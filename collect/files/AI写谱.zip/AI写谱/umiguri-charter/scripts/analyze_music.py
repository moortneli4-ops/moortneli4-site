from __future__ import annotations

import argparse
import csv
import json
import math
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

AUDIO_EXTENSIONS = {
    ".aac",
    ".aiff",
    ".alac",
    ".flac",
    ".m4a",
    ".mp3",
    ".ogg",
    ".opus",
    ".wav",
    ".wma",
}

BANDS = {
    "sub": (20.0, 60.0),
    "bass": (60.0, 180.0),
    "low_mid": (180.0, 500.0),
    "mid": (500.0, 2000.0),
    "high_mid": (2000.0, 6000.0),
    "high": (6000.0, 11025.0),
}

GRID_DIVISIONS_PER_BAR = [4, 8, 12, 16, 24, 32, 48]


@dataclass(frozen=True)
class AnalysisConfig:
    sample_rate: int = 22050
    frame_size: int = 2048
    hop_size: int = 512
    min_bpm: float = 70.0
    max_bpm: float = 220.0
    beats_per_bar: int = 4


def run_json(command: list[str]) -> Any:
    output = subprocess.check_output(command, text=True, encoding="utf-8")
    return json.loads(output)


def run_bytes(command: list[str]) -> bytes:
    return subprocess.check_output(command)


def require_tool(name: str) -> str:
    tool = shutil.which(name)
    if tool is None:
        raise SystemExit(f"Missing required executable: {name}")
    return tool


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9_.-]+", "_", value.strip())
    return slug.strip("._") or "song"


def load_metadata(song_path: Path, explicit_path: Path | None) -> dict[str, Any]:
    candidates: list[Path] = []
    if explicit_path is not None:
        candidates.append(explicit_path)
    candidates.extend(
        [
            song_path.with_suffix(".metadata.json"),
            song_path.parent / f"{song_path.stem}.metadata.json",
            song_path.parent / "metadata.json",
        ]
    )
    for candidate in candidates:
        if candidate.exists():
            with candidate.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
            if isinstance(data, dict):
                return data
            raise SystemExit(f"Metadata must be a JSON object: {candidate}")
    return {}


def probe_audio(song_path: Path, ffprobe: str) -> dict[str, Any]:
    return run_json(
        [
            ffprobe,
            "-v",
            "error",
            "-show_format",
            "-show_streams",
            "-of",
            "json",
            str(song_path),
        ]
    )


def decode_audio(song_path: Path, ffmpeg: str, sample_rate: int) -> np.ndarray:
    raw = run_bytes(
        [
            ffmpeg,
            "-v",
            "error",
            "-i",
            str(song_path),
            "-ac",
            "1",
            "-ar",
            str(sample_rate),
            "-f",
            "f32le",
            "-",
        ]
    )
    samples = np.frombuffer(raw, dtype=np.float32).copy()
    if samples.size == 0:
        raise SystemExit(f"Decoded audio is empty: {song_path}")
    return np.nan_to_num(samples, copy=False)


def frame_audio(samples: np.ndarray, frame_size: int, hop_size: int) -> np.ndarray:
    if samples.size < frame_size:
        samples = np.pad(samples, (0, frame_size - samples.size))
    remainder = (samples.size - frame_size) % hop_size
    if remainder:
        samples = np.pad(samples, (0, hop_size - remainder))
    count = 1 + (samples.size - frame_size) // hop_size
    return np.lib.stride_tricks.as_strided(
        samples,
        shape=(count, frame_size),
        strides=(samples.strides[0] * hop_size, samples.strides[0]),
        writeable=False,
    )


def moving_average(values: np.ndarray, width: int) -> np.ndarray:
    if width <= 1 or values.size == 0:
        return values
    kernel = np.ones(width, dtype=np.float32) / width
    return np.convolve(values, kernel, mode="same")


def normalize(values: np.ndarray) -> np.ndarray:
    if values.size == 0:
        return values
    low = float(np.quantile(values, 0.05))
    high = float(np.quantile(values, 0.98))
    if high <= low:
        return np.zeros_like(values, dtype=np.float32)
    return np.clip((values - low) / (high - low), 0.0, 1.0).astype(np.float32)


def compute_features(samples: np.ndarray, config: AnalysisConfig) -> dict[str, Any]:
    frames = frame_audio(samples, config.frame_size, config.hop_size)
    window = np.hanning(config.frame_size).astype(np.float32)
    spectrum = np.fft.rfft(frames * window, axis=1)
    magnitude = np.abs(spectrum).astype(np.float32)
    log_magnitude = np.log1p(magnitude)
    flux = np.maximum(np.diff(log_magnitude, axis=0), 0.0).sum(axis=1)
    onset_envelope = normalize(moving_average(np.pad(flux, (1, 0)), 3))
    rms = np.sqrt(np.mean(np.square(frames), axis=1))
    rms_envelope = normalize(moving_average(rms, 5))
    freqs = np.fft.rfftfreq(config.frame_size, 1.0 / config.sample_rate)
    band_energy: dict[str, np.ndarray] = {}
    for name, (low, high) in BANDS.items():
        mask = (freqs >= low) & (freqs < high)
        if np.any(mask):
            band_energy[name] = normalize(np.log1p(np.mean(magnitude[:, mask], axis=1)))
        else:
            band_energy[name] = np.zeros(frames.shape[0], dtype=np.float32)
    times = (
        np.arange(frames.shape[0]) * config.hop_size + config.frame_size / 2.0
    ) / config.sample_rate
    return {
        "times": times,
        "onset_envelope": onset_envelope,
        "rms_envelope": rms_envelope,
        "band_energy": band_energy,
    }


def pick_onsets(
    features: dict[str, Any],
    config: AnalysisConfig,
    threshold_quantile: float = 0.72,
    std_weight: float = 0.5,
    min_gap_seconds: float = 0.075,
) -> list[dict[str, Any]]:
    envelope = features["onset_envelope"]
    times = features["times"]
    if envelope.size < 3:
        return []
    threshold = max(
        float(np.mean(envelope) + std_weight * np.std(envelope)),
        float(np.quantile(envelope, threshold_quantile)),
    )
    local = (
        np.flatnonzero(
            (envelope[1:-1] >= envelope[:-2])
            & (envelope[1:-1] > envelope[2:])
            & (envelope[1:-1] >= threshold)
        )
        + 1
    )
    min_gap = max(1, int(round(min_gap_seconds / (config.hop_size / config.sample_rate))))
    chosen: list[int] = []
    for index in sorted(local.tolist(), key=lambda i: float(envelope[i]), reverse=True):
        if all(abs(index - other) >= min_gap for other in chosen):
            chosen.append(index)
    chosen.sort()
    band_energy = features["band_energy"]
    events: list[dict[str, Any]] = []
    for index in chosen:
        bands = {name: float(values[index]) for name, values in band_energy.items()}
        family = classify_onset(bands)
        events.append(
            {
                "time": round(float(times[index]), 6),
                "score": round(float(envelope[index]), 6),
                "family": family,
                "bands": {name: round(value, 6) for name, value in bands.items()},
            }
        )
    return events


def classify_onset(bands: dict[str, float]) -> str:
    low = bands["sub"] + bands["bass"]
    body = bands["low_mid"] + bands["mid"]
    bright = bands["high_mid"] + bands["high"]
    if low >= body * 1.15 and low >= bright * 1.15:
        return "kick_or_bass"
    if bright >= body * 1.2 and bright >= low:
        return "hat_clap_or_noise"
    if body >= low and body >= bright:
        return "melody_or_vocal"
    return "mixed_accent"


def tempo_candidates(onset_envelope: np.ndarray, config: AnalysisConfig) -> list[dict[str, float]]:
    if onset_envelope.size < 8:
        return []
    rate = config.sample_rate / config.hop_size
    values = onset_envelope.astype(np.float32) - float(np.mean(onset_envelope))
    min_lag = max(1, int(round(rate * 60.0 / config.max_bpm)))
    max_lag = min(values.size - 2, int(round(rate * 60.0 / config.min_bpm)))
    if max_lag <= min_lag:
        return []
    scores = []
    for lag in range(min_lag, max_lag + 1):
        left = values[:-lag]
        right = values[lag:]
        score = float(np.dot(left, right) / max(1, left.size))
        bpm = 60.0 * rate / lag
        preference = math.exp(-((math.log2(bpm / 140.0)) ** 2) / 1.8)
        scores.append((lag, bpm, score * (0.9 + 0.1 * preference)))
    raw = np.array([score for _, _, score in scores], dtype=np.float32)
    normalized = normalize(raw)
    peaks: list[tuple[int, float, float]] = []
    for idx in range(1, len(scores) - 1):
        if normalized[idx] >= normalized[idx - 1] and normalized[idx] > normalized[idx + 1]:
            lag, bpm, _ = scores[idx]
            peaks.append((lag, bpm, float(normalized[idx])))
    if not peaks:
        peaks = [
            (lag, bpm, float(score))
            for (lag, bpm, _), score in zip(scores, normalized, strict=True)
        ]
    peaks.sort(key=lambda item: item[2], reverse=True)
    result = []
    for lag, bpm, score in peaks:
        if all(abs(bpm - existing["bpm"]) > 1.0 for existing in result):
            result.append(
                {"bpm": round(bpm, 4), "lag_frames": float(lag), "score": round(score, 6)}
            )
        if len(result) >= 8:
            break
    return result


def score_grid(onsets: list[dict[str, Any]], bpm: float, offset: float) -> float:
    if not onsets:
        return 0.0
    period = 60.0 / bpm
    tolerance = min(0.08, period * 0.16)
    score = 0.0
    total = 0.0
    for event in onsets:
        time = float(event["time"])
        weight = float(event["score"])
        nearest = round((time - offset) / period)
        distance = abs(time - (offset + nearest * period))
        total += weight
        if distance <= tolerance:
            score += weight * (1.0 - distance / tolerance)
    return score / total if total > 0.0 else 0.0


def estimate_grid(
    onsets: list[dict[str, Any]],
    duration: float,
    tempo_options: list[dict[str, float]],
    config: AnalysisConfig,
) -> dict[str, Any]:
    if not tempo_options:
        return {"bpm": None, "offset": 0.0, "confidence": 0.0, "beats": []}
    weighted_onsets = [event for event in onsets if float(event["score"]) >= 0.25]
    if not weighted_onsets:
        weighted_onsets = onsets
    best: dict[str, Any] | None = None
    for option in tempo_options[:5]:
        bpm = float(option["bpm"])
        period = 60.0 / bpm
        bins = 96
        histogram = np.zeros(bins, dtype=np.float32)
        for event in weighted_onsets:
            phase = (float(event["time"]) % period) / period
            histogram[int(phase * bins) % bins] += float(event["score"])
        histogram = moving_average(histogram, 5)
        phase_index = int(np.argmax(histogram))
        raw_offset = (phase_index + 0.5) / bins * period
        offset = raw_offset
        while offset > 0.0:
            offset -= period
        while offset + period <= 0.0:
            offset += period
        confidence = score_grid(weighted_onsets, bpm, offset)
        candidate = {"bpm": bpm, "offset": offset, "confidence": confidence}
        if best is None or candidate["confidence"] > best["confidence"]:
            best = candidate
    assert best is not None
    bpm = float(best["bpm"])
    period = 60.0 / bpm
    first = float(best["offset"])
    while first < 0.0:
        first += period
    beats = []
    time = first
    index = 0
    while time <= duration + period * 0.5:
        beats.append(
            {
                "beat_index": index,
                "bar_index": index // config.beats_per_bar,
                "beat_in_bar": index % config.beats_per_bar,
                "time": round(time, 6),
            }
        )
        index += 1
        time += period
    return {
        "source": "estimated",
        "bpm": round(bpm, 4),
        "offset": round(float(best["offset"]), 6),
        "first_beat_time": round(first, 6),
        "confidence": round(float(best["confidence"]), 6),
        "timing_changes": [{"beat_index": 0, "time": round(first, 6), "bpm": round(bpm, 4)}],
        "beats": beats,
    }


def load_timing_changes(
    timing_map_path: Path | None,
    known_bpm: float | None,
    known_offset: float,
) -> list[dict[str, float]] | None:
    if timing_map_path is None and known_bpm is None:
        return None
    if timing_map_path is None:
        assert known_bpm is not None
        return [{"beat_index": 0.0, "time": known_offset, "bpm": known_bpm}]
    with timing_map_path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if isinstance(data, dict):
        raw_changes = data.get("timing_changes", data.get("bpm_changes", data.get("changes")))
    else:
        raw_changes = data
    if not isinstance(raw_changes, list) or not raw_changes:
        raise SystemExit(f"Timing map must contain a non-empty change list: {timing_map_path}")
    changes = []
    for raw in raw_changes:
        if not isinstance(raw, dict):
            raise SystemExit(f"Timing change entries must be objects: {timing_map_path}")
        beat = raw.get("beat_index", raw.get("beat", raw.get("tick")))
        time = raw.get("time", raw.get("seconds", raw.get("sec")))
        bpm = raw.get("bpm")
        if beat is None or time is None or bpm is None:
            raise SystemExit(
                "Timing changes require beat_index/beat, time/seconds, and bpm fields."
            )
        changes.append({"beat_index": float(beat), "time": float(time), "bpm": float(bpm)})
    changes.sort(key=lambda item: (item["beat_index"], item["time"]))
    return changes


def grid_from_timing_changes(
    changes: list[dict[str, float]],
    duration: float,
    config: AnalysisConfig,
) -> dict[str, Any]:
    beats: list[dict[str, Any]] = []
    normalized_changes = [
        {
            "beat_index": int(round(change["beat_index"])),
            "time": round(float(change["time"]), 6),
            "bpm": round(float(change["bpm"]), 4),
        }
        for change in changes
    ]
    for index, change in enumerate(normalized_changes):
        start_beat = int(change["beat_index"])
        start_time = float(change["time"])
        bpm = float(change["bpm"])
        period = 60.0 / bpm
        next_change = normalized_changes[index + 1] if index + 1 < len(normalized_changes) else None
        end_beat = int(next_change["beat_index"]) if next_change else math.inf
        beat_index = start_beat
        while beat_index < end_beat:
            time = start_time + (beat_index - start_beat) * period
            if time > duration + period * 0.5:
                break
            if time >= -period * 0.5:
                beats.append(
                    {
                        "beat_index": beat_index,
                        "bar_index": beat_index // config.beats_per_bar,
                        "beat_in_bar": beat_index % config.beats_per_bar,
                        "time": round(time, 6),
                        "bpm": round(bpm, 4),
                    }
                )
            beat_index += 1
    beats.sort(key=lambda beat: beat["beat_index"])
    first_beat_time = next((beat["time"] for beat in beats if beat["beat_index"] >= 0), 0.0)
    return {
        "source": "provided",
        "bpm": normalized_changes[0]["bpm"],
        "offset": normalized_changes[0]["time"],
        "first_beat_time": first_beat_time,
        "confidence": 1.0,
        "timing_changes": normalized_changes,
        "beats": beats,
    }


def nearest_frame_index(times: np.ndarray, value: float) -> int:
    return int(np.clip(np.searchsorted(times, value), 0, max(0, times.size - 1)))


def summarize_bars(
    features: dict[str, Any],
    onsets: list[dict[str, Any]],
    grid: dict[str, Any],
    duration: float,
    config: AnalysisConfig,
) -> list[dict[str, Any]]:
    beats = grid.get("beats", [])
    if not beats:
        return []
    times = features["times"]
    rms = features["rms_envelope"]
    bands = features["band_energy"]
    bars = []
    bar_starts = [beat for beat in beats if int(beat["beat_in_bar"]) == 0]
    for index, beat in enumerate(bar_starts):
        current = float(beat["time"])
        if current > duration:
            break
        if index + 1 < len(bar_starts):
            end = float(bar_starts[index + 1]["time"])
        else:
            beat_period = 60.0 / float(beat.get("bpm", grid.get("bpm") or 120.0))
            end = current + beat_period * config.beats_per_bar
        left = nearest_frame_index(times, max(0.0, current))
        right = nearest_frame_index(times, min(duration, end))
        if right <= left:
            right = min(left + 1, times.size)
        local_onsets = [event for event in onsets if current <= float(event["time"]) < end]
        energy = float(np.mean(rms[left:right])) if right > left else 0.0
        brightness = float(np.mean(bands["high_mid"][left:right] + bands["high"][left:right]))
        bass = float(np.mean(bands["sub"][left:right] + bands["bass"][left:right]))
        density = len(local_onsets) / max(0.001, end - current)
        bars.append(
            {
                "bar_index": int(beat["bar_index"]),
                "start": round(max(0.0, current), 6),
                "end": round(min(duration, end), 6),
                "energy": round(energy, 6),
                "onset_density": round(density, 6),
                "bass": round(bass, 6),
                "brightness": round(brightness, 6),
                "accent_count": len(local_onsets),
            }
        )
    return bars


def normalize_feature_column(values: list[float]) -> np.ndarray:
    array = np.array(values, dtype=np.float32)
    if array.size == 0:
        return array
    low = float(np.min(array))
    high = float(np.max(array))
    if high <= low:
        return np.zeros_like(array)
    return (array - low) / (high - low)


def bar_feature_vectors(bars: list[dict[str, Any]]) -> np.ndarray:
    columns = [
        normalize_feature_column([float(bar["energy"]) for bar in bars]),
        normalize_feature_column([float(bar["onset_density"]) for bar in bars]),
        normalize_feature_column([float(bar["bass"]) for bar in bars]),
        normalize_feature_column([float(bar["brightness"]) for bar in bars]),
    ]
    return np.stack(columns, axis=1)


def summarize_phrases(
    bars: list[dict[str, Any]],
    phrase_bars: int,
    label_prefix: str,
) -> list[dict[str, Any]]:
    phrases = []
    for start in range(0, len(bars), phrase_bars):
        subset = bars[start : start + phrase_bars]
        if not subset:
            continue
        phrases.append(
            {
                "label": f"{label_prefix}_{len(phrases) + 1}",
                "start": subset[0]["start"],
                "end": subset[-1]["end"],
                "start_bar": subset[0]["bar_index"],
                "end_bar": subset[-1]["bar_index"],
                "bar_count": len(subset),
                "energy": round(float(np.mean([bar["energy"] for bar in subset])), 6),
                "onset_density": round(float(np.mean([bar["onset_density"] for bar in subset])), 6),
                "bass": round(float(np.mean([bar["bass"] for bar in subset])), 6),
                "brightness": round(float(np.mean([bar["brightness"] for bar in subset])), 6),
                "accent_count": int(sum(int(bar["accent_count"]) for bar in subset)),
            }
        )
    return phrases


def summarize_phrase_features(bars: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    return {
        "four_bar": summarize_phrases(bars, 4, "four_bar"),
        "eight_bar": summarize_phrases(bars, 8, "eight_bar"),
        "sixteen_bar": summarize_phrases(bars, 16, "sixteen_bar"),
    }


def suggest_sections(bars: list[dict[str, Any]], duration: float) -> list[dict[str, Any]]:
    if not bars:
        return [{"label": "full_song", "start": 0.0, "end": round(duration, 6)}]
    vectors = bar_feature_vectors(bars)
    if len(bars) < 8:
        return [
            {
                "label": classify_section(bars, 0, len(bars)),
                "start": bars[0]["start"],
                "end": bars[-1]["end"],
                "start_bar": bars[0]["bar_index"],
                "end_bar": bars[-1]["bar_index"],
            }
        ]
    scores: dict[int, float] = {}
    for boundary in range(4, len(bars), 4):
        window = 4 if boundary >= 4 and len(bars) - boundary >= 4 else 2
        left = vectors[max(0, boundary - window) : boundary]
        right = vectors[boundary : min(len(bars), boundary + window)]
        if left.size == 0 or right.size == 0:
            continue
        contrast = float(np.linalg.norm(np.mean(right, axis=0) - np.mean(left, axis=0)))
        energy_cut = max(
            0.0,
            float(np.mean(left[:, 0]) - np.mean(right[:, 0])),
            float(np.mean(right[:, 0]) - np.mean(left[:, 0])) * 0.55,
        )
        phrase_bonus = 0.0
        if boundary % 16 == 0:
            phrase_bonus = 0.16
        elif boundary % 8 == 0:
            phrase_bonus = 0.11
        scores[boundary] = contrast + energy_cut + phrase_bonus
    if not scores:
        return [
            {
                "label": classify_section(bars, 0, len(bars)),
                "start": bars[0]["start"],
                "end": bars[-1]["end"],
                "start_bar": bars[0]["bar_index"],
                "end_bar": bars[-1]["bar_index"],
            }
        ]
    score_values = np.array(list(scores.values()), dtype=np.float32)
    threshold = max(float(np.quantile(score_values, 0.58)), float(np.mean(score_values)))
    candidates = [
        boundary
        for boundary, score in scores.items()
        if score >= threshold or (boundary % 16 == 0 and score >= threshold * 0.78)
    ]
    boundaries = [0]
    for candidate in candidates:
        if candidate - boundaries[-1] >= 4 and len(bars) - candidate >= 4:
            boundaries.append(candidate)
    if len(bars) - boundaries[-1] < 4 and len(boundaries) > 1:
        boundaries.pop()
    boundaries.append(len(bars))
    expanded_boundaries = [boundaries[0]]
    for boundary in boundaries[1:]:
        while boundary - expanded_boundaries[-1] > 16:
            split = expanded_boundaries[-1] + 16
            if boundary - split < 4:
                break
            expanded_boundaries.append(split)
        expanded_boundaries.append(boundary)
    boundaries = expanded_boundaries
    sections = []
    for number, (start_index, end_index) in enumerate(zip(boundaries, boundaries[1:]), start=1):
        subset = bars[start_index:end_index]
        sections.append(
            {
                "label": classify_section(bars, start_index, end_index, number),
                "start": subset[0]["start"],
                "end": subset[-1]["end"],
                "start_bar": subset[0]["bar_index"],
                "end_bar": subset[-1]["bar_index"],
                "bar_count": len(subset),
                "boundary_score": round(scores.get(start_index, 0.0), 6),
            }
        )
    return sections


def local_beat_period(beats: list[dict[str, Any]], index: int) -> float:
    if index + 1 < len(beats):
        return max(0.001, float(beats[index + 1]["time"]) - float(beats[index]["time"]))
    if index > 0:
        return max(0.001, float(beats[index]["time"]) - float(beats[index - 1]["time"]))
    bpm = float(beats[index].get("bpm", 120.0))
    return 60.0 / bpm


def beat_position_for_time(grid: dict[str, Any], time: float) -> tuple[float, float]:
    beats = grid.get("beats", [])
    if not beats:
        bpm = float(grid.get("bpm") or 120.0)
        period = 60.0 / bpm
        return (time - float(grid.get("offset", 0.0))) / period, period
    beat_times = [float(beat["time"]) for beat in beats]
    index = int(np.searchsorted(beat_times, time, side="right") - 1)
    index = max(0, min(index, len(beats) - 1))
    period = local_beat_period(beats, index)
    beat_index = float(beats[index]["beat_index"])
    return beat_index + (time - float(beats[index]["time"])) / period, period


def grid_error_for_division(
    beat_position: float,
    beat_period: float,
    divisions_per_bar: int,
    config: AnalysisConfig,
) -> tuple[float, float, int]:
    units_per_beat = divisions_per_bar / config.beats_per_bar
    nearest_unit = int(round(beat_position * units_per_beat))
    nearest_beat = nearest_unit / units_per_beat
    error_seconds = abs(beat_position - nearest_beat) * beat_period
    return nearest_beat, error_seconds, nearest_unit


def annotate_onset_grid_alignment(
    onsets: list[dict[str, Any]],
    grid: dict[str, Any],
    config: AnalysisConfig,
) -> dict[str, Any]:
    per_division: dict[str, dict[str, Any]] = {}
    preferred_counts = {str(division): 0 for division in GRID_DIVISIONS_PER_BAR}
    preferred_counts["off_grid"] = 0
    best_counts = {str(division): 0 for division in GRID_DIVISIONS_PER_BAR}
    phase_counts = {
        str(division): {str(unit): 0 for unit in range(division)}
        for division in GRID_DIVISIONS_PER_BAR
    }
    tolerance_seconds = 0.025
    for event in onsets:
        time = float(event["time"])
        beat_position, beat_period = beat_position_for_time(grid, time)
        bar_position = beat_position / config.beats_per_bar
        errors: dict[str, float] = {}
        best: tuple[int, float, float, int] | None = None
        for division in GRID_DIVISIONS_PER_BAR:
            nearest_beat, error_seconds, nearest_unit = grid_error_for_division(
                beat_position, beat_period, division, config
            )
            errors[str(division)] = round(error_seconds, 6)
            if error_seconds <= tolerance_seconds:
                phase_counts[str(division)][str(nearest_unit % division)] += 1
            if best is None or error_seconds < best[1]:
                best = (division, error_seconds, nearest_beat, nearest_unit)
        preferred = "off_grid"
        for division in GRID_DIVISIONS_PER_BAR:
            if errors[str(division)] <= tolerance_seconds:
                preferred = str(division)
                break
        preferred_counts[preferred] += 1
        assert best is not None
        best_counts[str(best[0])] += 1
        event["grid"] = {
            "beat_position": round(beat_position, 6),
            "bar_position": round(bar_position, 6),
            "best_divisions_per_bar": best[0],
            "best_error_seconds": round(best[1], 6),
            "preferred_divisions_per_bar": preferred,
            "nearest_beat_position": round(best[2], 6),
            "nearest_grid_unit": best[3],
            "errors_seconds": errors,
        }
    for division in GRID_DIVISIONS_PER_BAR:
        key = str(division)
        errors = np.array([float(event["grid"]["errors_seconds"][key]) for event in onsets])
        per_division[key] = {
            "within_15ms": int(np.sum(errors <= 0.015)),
            "within_25ms": int(np.sum(errors <= 0.025)),
            "median_error_ms": round(float(np.median(errors)) * 1000.0, 3) if errors.size else None,
            "p90_error_ms": round(float(np.quantile(errors, 0.9)) * 1000.0, 3)
            if errors.size
            else None,
        }
    return {
        "divisions_per_bar": GRID_DIVISIONS_PER_BAR,
        "preferred_tolerance_ms": round(tolerance_seconds * 1000.0, 3),
        "preferred_counts": preferred_counts,
        "best_counts": best_counts,
        "phase_counts": phase_counts,
        "vocabulary_counts": {
            "bar_12_triplet_inner_units": int(
                sum(count for unit, count in phase_counts["12"].items() if int(unit) % 3 != 0)
            ),
            "bar_24_eighth_offbeat_units": int(
                sum(
                    count
                    for unit, count in phase_counts["24"].items()
                    if int(unit) % 3 == 0 and int(unit) % 6 != 0
                )
            ),
            "bar_24_triplet_inner_units": int(
                sum(
                    count
                    for unit, count in phase_counts["24"].items()
                    if int(unit) % 2 == 0 and int(unit) % 6 != 0
                )
            ),
            "bar_24_fine_units": int(
                sum(
                    count
                    for unit, count in phase_counts["24"].items()
                    if int(unit) % 2 != 0 and int(unit) % 3 != 0
                )
            ),
        },
        "per_division": per_division,
    }


def attach_bar_subdivision_profiles(
    bars: list[dict[str, Any]],
    onsets: list[dict[str, Any]],
) -> None:
    for bar in bars:
        counts = {str(division): 0 for division in GRID_DIVISIONS_PER_BAR}
        counts["off_grid"] = 0
        start_bar = int(bar["bar_index"])
        for event in onsets:
            grid_info = event.get("grid")
            if not isinstance(grid_info, dict):
                continue
            event_bar = int(math.floor(float(grid_info["bar_position"])))
            if event_bar == start_bar:
                preferred = str(grid_info["preferred_divisions_per_bar"])
                counts[preferred] = counts.get(preferred, 0) + 1
        bar["subdivision_counts"] = counts


def classify_section(
    bars: list[dict[str, Any]],
    start_index: int,
    end_index: int,
    number: int | None = None,
) -> str:
    subset = bars[start_index:end_index]
    energy = float(np.mean([bar["energy"] for bar in subset]))
    density = float(np.mean([bar["onset_density"] for bar in subset]))
    bass = float(np.mean([bar["bass"] for bar in subset]))
    all_energy = np.array([bar["energy"] for bar in bars], dtype=np.float32)
    energy_rank = float(np.mean(all_energy <= energy))
    if end_index == len(bars) and energy_rank < 0.35:
        base = "outro"
    elif start_index == 0 and energy_rank < 0.45:
        base = "intro"
    elif energy_rank >= 0.75 and density >= 2.0 and bass >= 0.45:
        base = "drop_or_chorus"
    elif energy_rank <= 0.35:
        base = "break_or_build"
    else:
        base = "phrase"
    return f"{base}_{number}" if number is not None else base


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def render_images(song_path: Path, output_dir: Path, ffmpeg: str) -> None:
    waveform = output_dir / "waveform.png"
    spectrogram = output_dir / "spectrogram.png"
    subprocess.run(
        [
            ffmpeg,
            "-y",
            "-v",
            "error",
            "-i",
            str(song_path),
            "-filter_complex",
            "aformat=channel_layouts=mono,showwavespic=s=1800x320:colors=4cc9f0",
            "-frames:v",
            "1",
            str(waveform),
        ],
        check=True,
    )
    subprocess.run(
        [
            ffmpeg,
            "-y",
            "-v",
            "error",
            "-i",
            str(song_path),
            "-lavfi",
            "showspectrumpic=s=1800x640:legend=disabled:scale=log:color=intensity",
            str(spectrogram),
        ],
        check=True,
    )


def analyze_song(
    song_path: Path,
    output_root: Path,
    metadata_path: Path | None,
    difficulty: str | None,
    chart_style: str | None,
    write_images: bool,
    config: AnalysisConfig,
    ffmpeg: str,
    ffprobe: str,
    timing_changes: list[dict[str, float]] | None,
) -> Path:
    probe = probe_audio(song_path, ffprobe)
    samples = decode_audio(song_path, ffmpeg, config.sample_rate)
    duration = samples.size / config.sample_rate
    features = compute_features(samples, config)
    onsets = pick_onsets(features, config)
    rhythm_onsets = pick_onsets(
        features,
        config,
        threshold_quantile=0.52,
        std_weight=0.15,
        min_gap_seconds=0.035,
    )
    tempos = tempo_candidates(features["onset_envelope"], config)
    grid = (
        grid_from_timing_changes(timing_changes, duration, config)
        if timing_changes is not None
        else estimate_grid(onsets, duration, tempos, config)
    )
    grid_alignment = annotate_onset_grid_alignment(onsets, grid, config)
    rhythm_grid_alignment = annotate_onset_grid_alignment(rhythm_onsets, grid, config)
    bars = summarize_bars(features, onsets, grid, duration, config)
    attach_bar_subdivision_profiles(bars, onsets)
    sections = suggest_sections(bars, duration)
    phrase_features = summarize_phrase_features(bars)
    metadata = load_metadata(song_path, metadata_path)
    output_dir = output_root / slugify(song_path.stem)
    analysis = {
        "song": {
            "path": str(song_path),
            "filename": song_path.name,
            "duration": round(duration, 6),
            "sample_rate": config.sample_rate,
            "metadata": metadata,
        },
        "chart_request": {
            "desired_difficulty": difficulty,
            "chart_style": chart_style,
        },
        "audio_probe": probe,
        "tempo_candidates": tempos,
        "beat_grid": {key: value for key, value in grid.items() if key != "beats"},
        "grid_alignment": grid_alignment,
        "rhythm_grid_alignment": rhythm_grid_alignment,
        "sections": sections,
        "phrase_features": phrase_features,
        "summary": {
            "onset_count": len(onsets),
            "rhythm_onset_count": len(rhythm_onsets),
            "bar_count": len(bars),
            "beat_count": len(grid.get("beats", [])),
            "primary_bpm": grid.get("bpm"),
            "grid_confidence": grid.get("confidence"),
        },
    }
    write_json(output_dir / "analysis.json", analysis)
    write_json(output_dir / "beat_grid.json", grid)
    write_json(output_dir / "onsets.json", onsets)
    write_json(output_dir / "rhythm_onsets.json", rhythm_onsets)
    write_json(output_dir / "bar_features.json", bars)
    write_json(output_dir / "sections.json", sections)
    write_json(output_dir / "phrase_features.json", phrase_features)
    write_json(output_dir / "grid_alignment.json", grid_alignment)
    write_json(output_dir / "rhythm_grid_alignment.json", rhythm_grid_alignment)
    write_csv(
        output_dir / "beat_grid.csv",
        grid.get("beats", []),
        ["beat_index", "bar_index", "beat_in_bar", "time"],
    )
    write_csv(output_dir / "onsets.csv", onsets, ["time", "score", "family"])
    write_csv(output_dir / "rhythm_onsets.csv", rhythm_onsets, ["time", "score", "family"])
    write_csv(
        output_dir / "onset_alignment.csv",
        [
            {
                "time": event["time"],
                "score": event["score"],
                "family": event["family"],
                "beat_position": event["grid"]["beat_position"],
                "bar_position": event["grid"]["bar_position"],
                "preferred_divisions_per_bar": event["grid"]["preferred_divisions_per_bar"],
                "best_divisions_per_bar": event["grid"]["best_divisions_per_bar"],
                "best_error_seconds": event["grid"]["best_error_seconds"],
            }
            for event in onsets
        ],
        [
            "time",
            "score",
            "family",
            "beat_position",
            "bar_position",
            "preferred_divisions_per_bar",
            "best_divisions_per_bar",
            "best_error_seconds",
        ],
    )
    write_csv(
        output_dir / "bar_features.csv",
        bars,
        [
            "bar_index",
            "start",
            "end",
            "energy",
            "onset_density",
            "bass",
            "brightness",
            "accent_count",
        ],
    )
    if write_images:
        render_images(song_path, output_dir, ffmpeg)
    return output_dir


def find_audio_files(music_dir: Path) -> list[Path]:
    return sorted(
        path
        for path in music_dir.iterdir()
        if path.is_file() and path.suffix.lower() in AUDIO_EXTENSIONS
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze music files for future CHUNITHM chart authoring."
    )
    parser.add_argument(
        "--music-dir",
        type=Path,
        default=Path(__file__).resolve().parents[2] / "music",
    )
    parser.add_argument("--file", type=Path, action="append", default=[])
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--metadata", type=Path)
    parser.add_argument("--desired-difficulty")
    parser.add_argument("--chart-style")
    parser.add_argument("--bpm", type=float)
    parser.add_argument("--offset", type=float, default=0.0)
    parser.add_argument("--timing-map", type=Path)
    parser.add_argument("--sample-rate", type=int, default=22050)
    parser.add_argument("--min-bpm", type=float, default=70.0)
    parser.add_argument("--max-bpm", type=float, default=220.0)
    parser.add_argument("--no-images", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    ffmpeg = require_tool("ffmpeg")
    ffprobe = require_tool("ffprobe")
    music_dir = args.music_dir.resolve()
    output_dir = (args.output_dir or (music_dir / "_analysis")).resolve()
    files = [path.resolve() for path in args.file] if args.file else find_audio_files(music_dir)
    if not files:
        print(f"No audio files found in {music_dir}")
        return
    config = AnalysisConfig(
        sample_rate=args.sample_rate, min_bpm=args.min_bpm, max_bpm=args.max_bpm
    )
    timing_changes = load_timing_changes(
        args.timing_map.resolve() if args.timing_map else None,
        args.bpm,
        args.offset,
    )
    for song_path in files:
        if not song_path.exists():
            raise SystemExit(f"Audio file does not exist: {song_path}")
        destination = analyze_song(
            song_path=song_path,
            output_root=output_dir,
            metadata_path=args.metadata.resolve() if args.metadata else None,
            difficulty=args.desired_difficulty,
            chart_style=args.chart_style,
            write_images=not args.no_images,
            config=config,
            ffmpeg=ffmpeg,
            ffprobe=ffprobe,
            timing_changes=timing_changes,
        )
        print(f"Analyzed {song_path.name} -> {destination}")


if __name__ == "__main__":
    main()
