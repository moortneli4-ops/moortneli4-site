from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

GRID_DIVISIONS_PER_BAR = [4, 8, 12, 16, 24, 32, 48]


@dataclass(frozen=True)
class TimingPoint:
    time_ms: float
    beat_length: float
    meter: int
    sample_set: int
    sample_index: int
    volume: int
    uninherited: bool
    effects: int


@dataclass(frozen=True)
class HitObject:
    x: int
    y: int
    time_ms: int
    type_flags: int
    hit_sound: int
    params: list[str]
    raw: str


def read_osu_sections(path: Path) -> dict[str, list[str]]:
    text = path.read_text(encoding="utf-8-sig")
    sections: dict[str, list[str]] = {}
    current = ""
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("//"):
            continue
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1]
            sections.setdefault(current, [])
            continue
        sections.setdefault(current, []).append(line)
    return sections


def parse_key_value_section(lines: list[str]) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in lines:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        values[key.strip()] = value.strip()
    return values


def parse_timing_points(lines: list[str]) -> list[TimingPoint]:
    points = []
    for line in lines:
        parts = line.split(",")
        if len(parts) < 8:
            continue
        points.append(
            TimingPoint(
                time_ms=float(parts[0]),
                beat_length=float(parts[1]),
                meter=int(parts[2]),
                sample_set=int(parts[3]),
                sample_index=int(parts[4]),
                volume=int(parts[5]),
                uninherited=parts[6] == "1",
                effects=int(parts[7]),
            )
        )
    return sorted(points, key=lambda point: (point.time_ms, not point.uninherited))


def parse_hit_objects(lines: list[str]) -> list[HitObject]:
    objects = []
    for line in lines:
        parts = line.split(",")
        if len(parts) < 5:
            continue
        objects.append(
            HitObject(
                x=int(parts[0]),
                y=int(parts[1]),
                time_ms=int(parts[2]),
                type_flags=int(parts[3]),
                hit_sound=int(parts[4]),
                params=parts[5:],
                raw=line,
            )
        )
    return sorted(objects, key=lambda obj: (obj.time_ms, obj.x))


def try_parse_with_osupyparser(path: Path) -> dict[str, Any]:
    try:
        from osupyparser import OsuFile  # type: ignore[import-not-found]
    except Exception as exc:
        return {"available": False, "error": repr(exc)}
    try:
        parsed = OsuFile(str(path)).parse_file()
        return {"available": True, "parsed": True, "class": parsed.__class__.__name__}
    except ValueError as exc:
        message = str(exc)
        if "\\ufeff" not in message and "\ufeff" not in message:
            return {"available": True, "parsed": False, "error": message}
        with tempfile.NamedTemporaryFile(
            "w", encoding="utf-8", suffix=".osu", delete=False
        ) as handle:
            handle.write(path.read_text(encoding="utf-8-sig"))
            temp_path = Path(handle.name)
        try:
            parsed = OsuFile(str(temp_path)).parse_file()
            return {
                "available": True,
                "parsed": True,
                "class": parsed.__class__.__name__,
                "note": "Parsed after stripping UTF-8 BOM.",
            }
        except Exception as retry_exc:
            return {"available": True, "parsed": False, "error": repr(retry_exc)}
        finally:
            temp_path.unlink(missing_ok=True)
    except Exception as exc:
        return {"available": True, "parsed": False, "error": repr(exc)}


def object_kind(type_flags: int) -> str:
    if type_flags & 128:
        return "hold"
    if type_flags & 8:
        return "spinner"
    if type_flags & 2:
        return "slider"
    if type_flags & 1:
        return "circle"
    return "unknown"


def mania_column(x: int, key_count: int) -> int:
    return max(0, min(key_count - 1, int(math.floor(x * key_count / 512.0))))


def hold_end_ms(obj: HitObject) -> int | None:
    if not (obj.type_flags & 128) or not obj.params:
        return None
    return int(obj.params[0].split(":", 1)[0])


def first_redline(timing_points: list[TimingPoint]) -> TimingPoint | None:
    for point in timing_points:
        if point.uninherited and point.beat_length > 0:
            return point
    return None


def bpm_segments(timing_points: list[TimingPoint]) -> list[dict[str, Any]]:
    segments = []
    redlines = [point for point in timing_points if point.uninherited and point.beat_length > 0]
    for point in redlines:
        segments.append(
            {
                "time_ms": round(point.time_ms, 6),
                "bpm": round(60000.0 / point.beat_length, 6),
                "beat_length_ms": round(point.beat_length, 6),
                "meter": point.meter,
            }
        )
    return segments


def nearest_grid(
    beat_position: float,
    beat_length_seconds: float,
    divisions_per_bar: int,
    beats_per_bar: int,
) -> tuple[float, float, int]:
    units_per_beat = divisions_per_bar / beats_per_bar
    nearest_unit = int(round(beat_position * units_per_beat))
    nearest_beat = nearest_unit / units_per_beat
    error_seconds = abs(beat_position - nearest_beat) * beat_length_seconds
    return nearest_beat, error_seconds, nearest_unit


def summarize_grid_alignment(
    rows: list[dict[str, Any]], beats_per_bar: int, bpm: float
) -> dict[str, Any]:
    beat_length_seconds = 60.0 / bpm
    tolerance_seconds = 0.025
    phase_counts = {
        str(division): {str(unit): 0 for unit in range(division)}
        for division in GRID_DIVISIONS_PER_BAR
    }
    preferred_counts = {str(division): 0 for division in GRID_DIVISIONS_PER_BAR}
    preferred_counts["off_grid"] = 0
    best_counts = {str(division): 0 for division in GRID_DIVISIONS_PER_BAR}
    per_division: dict[str, dict[str, Any]] = {}
    for row in rows:
        beat_position = float(row["beat_position"])
        errors: dict[str, float] = {}
        best: tuple[int, float, float, int] | None = None
        for division in GRID_DIVISIONS_PER_BAR:
            nearest_beat, error, nearest_unit = nearest_grid(
                beat_position, beat_length_seconds, division, beats_per_bar
            )
            errors[str(division)] = error
            if error <= tolerance_seconds:
                phase_counts[str(division)][str(nearest_unit % division)] += 1
            if best is None or error < best[1]:
                best = (division, error, nearest_beat, nearest_unit)
        preferred = "off_grid"
        for division in GRID_DIVISIONS_PER_BAR:
            if errors[str(division)] <= tolerance_seconds:
                preferred = str(division)
                break
        assert best is not None
        preferred_counts[preferred] += 1
        best_counts[str(best[0])] += 1
        row["preferred_divisions_per_bar"] = preferred
        row["best_divisions_per_bar"] = best[0]
        row["best_error_seconds"] = round(best[1], 6)
        row["nearest_beat_position"] = round(best[2], 6)
        row["nearest_grid_unit"] = best[3]
    for division in GRID_DIVISIONS_PER_BAR:
        key = str(division)
        errors = []
        for row in rows:
            _, error, _ = nearest_grid(
                float(row["beat_position"]), beat_length_seconds, division, beats_per_bar
            )
            errors.append(error)
        errors = sorted(errors)
        per_division[key] = {
            "within_15ms": sum(error <= 0.015 for error in errors),
            "within_25ms": sum(error <= 0.025 for error in errors),
            "median_error_ms": round(errors[len(errors) // 2] * 1000.0, 3) if errors else None,
            "p90_error_ms": round(errors[int(len(errors) * 0.9)] * 1000.0, 3) if errors else None,
        }
    return {
        "divisions_per_bar": GRID_DIVISIONS_PER_BAR,
        "preferred_counts": preferred_counts,
        "best_counts": best_counts,
        "phase_counts": phase_counts,
        "vocabulary_counts": {
            "bar_12_triplet_inner_units": sum(
                count for unit, count in phase_counts["12"].items() if int(unit) % 3 != 0
            ),
            "bar_24_eighth_offbeat_units": sum(
                count
                for unit, count in phase_counts["24"].items()
                if int(unit) % 3 == 0 and int(unit) % 6 != 0
            ),
            "bar_24_triplet_inner_units": sum(
                count
                for unit, count in phase_counts["24"].items()
                if int(unit) % 2 == 0 and int(unit) % 6 != 0
            ),
            "bar_24_fine_units": sum(
                count
                for unit, count in phase_counts["24"].items()
                if int(unit) % 2 != 0 and int(unit) % 3 != 0
            ),
        },
        "per_division": per_division,
    }


def summarize_bars(
    rows: list[dict[str, Any]],
    beats_per_bar: int,
    duration_seconds: float | None,
) -> list[dict[str, Any]]:
    by_bar: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_bar[int(math.floor(float(row["bar_position"])))].append(row)
    max_bar = max(by_bar.keys(), default=-1)
    if duration_seconds is not None:
        max_bar = max(
            max_bar, int(math.ceil(float(rows[0]["bpm"]) * duration_seconds / 60.0 / beats_per_bar))
        )
    bars = []
    for bar_index in range(max_bar + 1):
        entries = by_bar.get(bar_index, [])
        times = sorted({entry["music_time"] for entry in entries})
        chord_counts = Counter(entry["chord_size"] for entry in entries)
        lanes = sorted({entry["column"] for entry in entries})
        bars.append(
            {
                "bar_index": bar_index,
                "object_count": len(entries),
                "rhythm_count": len(times),
                "max_chord_size": max(chord_counts.keys(), default=0),
                "chord_size_counts": {str(key): chord_counts[key] for key in sorted(chord_counts)},
                "lanes_used": lanes,
            }
        )
    return bars


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def analyze_osu_reference(
    osu_path: Path,
    output_root: Path,
    song_zero_ms: float | None,
    key_count_override: int | None,
) -> Path:
    sections = read_osu_sections(osu_path)
    general = parse_key_value_section(sections.get("General", []))
    metadata = parse_key_value_section(sections.get("Metadata", []))
    difficulty = parse_key_value_section(sections.get("Difficulty", []))
    timing_points = parse_timing_points(sections.get("TimingPoints", []))
    hit_objects = parse_hit_objects(sections.get("HitObjects", []))
    redline = first_redline(timing_points)
    if redline is None:
        raise SystemExit(f"No uninherited timing point found: {osu_path}")
    bpm = 60000.0 / redline.beat_length
    beats_per_bar = redline.meter
    zero_ms = float(song_zero_ms if song_zero_ms is not None else redline.time_ms)
    key_count = key_count_override or int(float(difficulty.get("CircleSize", "4")))
    rows = []
    chord_sizes_by_time = Counter(obj.time_ms for obj in hit_objects)
    for obj in hit_objects:
        kind = object_kind(obj.type_flags)
        music_time = (obj.time_ms - zero_ms) / 1000.0
        beat_position = music_time / (redline.beat_length / 1000.0)
        end_ms = hold_end_ms(obj)
        rows.append(
            {
                "osu_time_ms": obj.time_ms,
                "music_time": round(music_time, 6),
                "beat_position": round(beat_position, 6),
                "bar_position": round(beat_position / beats_per_bar, 6),
                "kind": kind,
                "column": mania_column(obj.x, key_count),
                "x": obj.x,
                "hit_sound": obj.hit_sound,
                "end_osu_time_ms": end_ms,
                "end_music_time": round((end_ms - zero_ms) / 1000.0, 6) if end_ms else None,
                "duration": round((end_ms - obj.time_ms) / 1000.0, 6) if end_ms else 0.0,
                "chord_size": chord_sizes_by_time[obj.time_ms],
                "bpm": round(bpm, 6),
            }
        )
    alignment = summarize_grid_alignment(rows, beats_per_bar, bpm)
    bars = summarize_bars(rows, beats_per_bar, None)
    output_dir = output_root / osu_path.stem
    summary = {
        "source": {
            "path": str(osu_path),
            "parser": try_parse_with_osupyparser(osu_path),
        },
        "general": general,
        "metadata": metadata,
        "difficulty": difficulty,
        "timing": {
            "song_zero_ms": zero_ms,
            "first_redline_ms": redline.time_ms,
            "bpm": round(bpm, 6),
            "beat_length_ms": round(redline.beat_length, 6),
            "beats_per_bar": beats_per_bar,
            "bpm_segments": bpm_segments(timing_points),
            "timing_point_count": len(timing_points),
        },
        "objects": {
            "count": len(hit_objects),
            "kind_counts": dict(Counter(row["kind"] for row in rows)),
            "rhythm_count": len({row["osu_time_ms"] for row in rows}),
            "max_chord_size": max((row["chord_size"] for row in rows), default=0),
            "key_count": key_count,
        },
        "grid_alignment": alignment,
    }
    write_json(output_dir / "osu_reference.json", summary)
    write_json(output_dir / "osu_hitobjects.json", rows)
    write_json(output_dir / "osu_bar_features.json", bars)
    write_csv(
        output_dir / "osu_hitobjects.csv",
        rows,
        [
            "osu_time_ms",
            "music_time",
            "beat_position",
            "bar_position",
            "kind",
            "column",
            "x",
            "duration",
            "chord_size",
            "preferred_divisions_per_bar",
            "best_divisions_per_bar",
            "best_error_seconds",
        ],
    )
    write_csv(
        output_dir / "osu_bar_features.csv",
        bars,
        ["bar_index", "object_count", "rhythm_count", "max_chord_size", "lanes_used"],
    )
    return output_dir


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze an optional osu! beatmap as charting reference."
    )
    parser.add_argument("--osu-file", type=Path, required=True)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parents[2] / "music" / "_analysis_osu",
    )
    parser.add_argument("--song-zero-ms", type=float)
    parser.add_argument("--key-count", type=int)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not args.osu_file.exists():
        raise SystemExit(f"osu file does not exist: {args.osu_file}")
    destination = analyze_osu_reference(
        osu_path=args.osu_file.resolve(),
        output_root=args.output_dir.resolve(),
        song_zero_ms=args.song_zero_ms,
        key_count_override=args.key_count,
    )
    print(f"Analyzed {args.osu_file.name} -> {destination}")
    if shutil.which("uv") is None:
        print(
            "OsuPyParser is optional; install examples/agent requirements if parser metadata is needed."
        )


if __name__ == "__main__":
    main()
