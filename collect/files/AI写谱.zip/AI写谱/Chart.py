from __future__ import annotations

# ruff: noqa: E402, I001

import argparse
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from margrete_rpc import Margrete
from margrete_rpc.chart import ChartNote, TICK_RESOLUTION
from margrete_rpc.chart.events import BeatEvent, BpmEvent, NoteSpeedEvent, TimelineSpeedEvent
from margrete_rpc.chart.notes import (
    Air,
    AirCrush,
    AirDirection,
    AirHold,
    ColorValue,
    Extap,
    ExtapDirection,
    Flick,
    FlickDirection,
    Hold,
    Slide,
    Tap,
)
from margrete_rpc.chart.util import Curve

BPM = 186.0
BEAT = TICK_RESOLUTION // 4
BAR = BEAT * 4
LANES = 16
COLORS = [
    ColorValue.SKY,
    ColorValue.BLUE,
    ColorValue.VIOLET,
    ColorValue.PINK,
    ColorValue.YELLOW,
    ColorValue.GREEN,
]
ROAMING_X = [0, 3, 7, 11, 5, 9, 12, 2, 6, 10, 4, 8, 1]


def tick(bar: int, unit: int = 0, *, div: int = 16) -> int:
    return bar * BAR + unit * BAR // div


def clamp_x(x: int, w: int) -> int:
    return max(0, min(LANES - w, x))


def roam(index: int, bar: int, *, mirror: bool = False, offset: int = 0) -> int:
    x = ROAMING_X[(index + bar + offset) % len(ROAMING_X)]
    return 12 - x if mirror else x


def tap(t: int, x: int, w: int = 2) -> Tap:
    return Tap(t=t, x=clamp_x(x, w), w=w)


def ex(t: int, x: int, w: int = 2, dir: ExtapDirection = ExtapDirection.UP) -> Extap:
    return Extap(t=t, x=clamp_x(x, w), w=w, dir=dir)


def flick(t: int, x: int, w: int = 2, right: bool = True) -> Flick:
    return Flick(
        t=t,
        x=clamp_x(x, w),
        w=w,
        dir=FlickDirection.RIGHT if right else FlickDirection.LEFT,
    )


def air_tap(
    t: int,
    x: int,
    w: int = 2,
    dir: AirDirection = AirDirection.UP,
    *,
    ex_parent: bool = False,
) -> ChartNote:
    host: Tap | Extap
    host = ex(t, x, w, ExtapDirection.UP) if ex_parent else tap(t, x, w)
    return host.with_air(Air(dir, t=t, x=host.x, w=host.w))


def hold(t0: int, t1: int, x: int, w: int = 2) -> Hold:
    x = clamp_x(x, w)
    return Hold(t=t0, x=x, w=w).with_step(t=t1, x=x, w=w)


def slide(t0: int, t1: int, x0: int, x1: int, w: int = 2) -> Slide:
    x0 = clamp_x(x0, w)
    x1 = clamp_x(x1, w)
    return Slide(t=t0, x=x0, w=w).with_step(t=t1, x=x1, w=w)


def width_slide(t0: int, t1: int, x0: int, w0: int, x1: int, w1: int) -> Slide:
    x0 = clamp_x(x0, w0)
    x1 = clamp_x(x1, w1)
    mid_w = max(1, min(12, (w0 + w1) // 2))
    mid_x = clamp_x((x0 + x1) // 2, mid_w)
    return (
        Slide(t=t0, x=x0, w=w0)
        .with_ctrl(t=(t0 + t1) // 2, x=mid_x, w=mid_w)
        .with_step(t=t1, x=x1, w=w1)
    )


def curve_slide(t0: int, t1: int, x0: int, x1: int, w: int = 2, *, bend: int = 7) -> Slide:
    mid = (t0 + t1) // 2
    xm = clamp_x((x0 + x1) // 2 + bend, w)
    return (
        Curve(t=t0, x=clamp_x(x0, w))
        .to(t=mid, x=xm, ease_x="out_sine")
        .to(t=t1, x=clamp_x(x1, w), ease_x="in_sine")
        .to_slide(w=w)
    )


def air_curve(t0: int, t1: int, x0: int, x1: int, w: int = 2, *, high: int = 118) -> ChartNote:
    x0 = clamp_x(x0, w)
    x1 = clamp_x(x1, w)
    mid = (t0 + t1) // 2
    path = (
        Curve(t=t0, x=x0, h=36)
        .to(t=mid, x=clamp_x((x0 + x1) // 2, w), h=high, ease_x="in_out_sine", ease_h="out_quad")
        .to(t=t1, x=x1, h=54, ease_x="in_out_sine", ease_h="in_quad")
    )
    air = path.to_air_slide(w=w)
    return Tap(t=t0, x=x0, w=w).with_air(air)


def crush(t0: int, t1: int, x0: int, x1: int, color: ColorValue) -> AirCrush:
    return (
        Curve(t=t0, x=clamp_x(x0, 3), h=42)
        .to(t=(t0 + t1) // 2, x=clamp_x((x0 + x1) // 2, 3), h=126, ease_x="out_cubic")
        .to(t=t1, x=clamp_x(x1, 3), h=70, ease_x="in_cubic")
        .to_air_crush(w=3, gap=(1, 16), color=color)
    )


def ribbon_slide(
    t0: int,
    t1: int,
    x0: int,
    x1: int,
    *,
    w: int = 2,
    phase: int = 0,
) -> Slide:
    x0 = clamp_x(x0, w)
    x1 = clamp_x(x1, w)
    q = (t1 - t0) // 4
    return (
        Curve(t=t0, x=x0)
        .to(t=t0 + q, x=clamp_x(x1, w), ease_x="out_quint")
        .to(t=t0 + 2 * q, x=clamp_x(2 + phase, w), ease_x="in_out_sine")
        .to(t=t0 + 3 * q, x=clamp_x(12 - phase, w), ease_x="out_circ")
        .to(t=t1, x=x1, ease_x="in_expo")
        .to_slide(w=w)
    )


def air_hold_gate(t0: int, t1: int, x: int, w: int = 4, *, high: int = 112) -> ChartNote:
    x = clamp_x(x, w)
    air = AirHold(t=t0, x=x, w=w, h=42).with_step(t=t1, x=x, w=w, h=high)
    return Tap(t=t0, x=x, w=w).with_air(air)


def zigzag_crush(
    t0: int,
    t1: int,
    *,
    left_first: bool,
    color: ColorValue,
    gap: tuple[int, int] = (1, 24),
) -> AirCrush:
    xs = [0, 12, 3, 10, 1] if left_first else [12, 0, 10, 3, 12]
    q = (t1 - t0) // 4
    path = Curve(t=t0, x=xs[0], h=48)
    for i, x in enumerate(xs[1:], start=1):
        path = path.to(
            t=t0 + q * i,
            x=clamp_x(x, 3),
            h=78 + (i % 2) * 52,
            ease_x="in_out_sine",
            ease_h="out_quad" if i % 2 else "in_quad",
        )
    return path.to_air_crush(w=3, gap=gap, color=color)


def add_backbeat(notes: list[ChartNote], bar: int, *, strong: bool = False) -> None:
    notes.append(ex(tick(bar, 0), 0, 4, ExtapDirection.IN_OUT))
    notes.append(ex(tick(bar, 8), 12, 4, ExtapDirection.IN_OUT))
    notes.append(tap(tick(bar, 4), 6, 4))
    notes.append(tap(tick(bar, 12), 6, 4))
    if strong:
        notes.append(air_tap(tick(bar, 0), 0, 4, AirDirection.UP_LEFT, ex_parent=True))
        notes.append(air_tap(tick(bar, 8), 12, 4, AirDirection.UP_RIGHT, ex_parent=True))


def piano_run(notes: list[ChartNote], bar: int, *, reverse: bool = False, dense: bool = False) -> None:
    lanes = [roam(i, bar, mirror=reverse, offset=bar % 5) for i in range(12)]
    if reverse:
        lanes = list(reversed(lanes))
    step = 1 if dense else 2
    count = 16 if dense else 8
    for i in range(count):
        tt = tick(bar, i * step, div=32 if dense else 16)
        lane = lanes[i % len(lanes)]
        if i % 7 == 6:
            notes.append(flick(tt, lane, 4, right=not reverse))
        elif i % 4 == 0:
            notes.append(ex(tt, lane, 4, ExtapDirection.UP))
        else:
            notes.append(tap(tt, lane, 4))


def split_jacks(notes: list[ChartNote], bar: int, *, mirror: bool = False) -> None:
    left = [0, 3, 6, 2]
    right = [11, 8, 12, 9]
    if mirror:
        left, right = [12 - x for x in right], [12 - x for x in left]
    for i in range(8):
        tt = tick(bar, i * 2, div=16)
        notes.append(tap(tt, left[i % 4], 4))
        if i % 2 == 0:
            notes.append(ex(tt, right[i % 4], 4, ExtapDirection.CENTER))
        else:
            notes.append(flick(tt, right[i % 4], 4, right=i % 4 == 1))


def drum_roll(notes: list[ChartNote], bar: int, *, peak: bool = False) -> None:
    for i in range(16):
        tt = tick(bar, i, div=16)
        if i % 4 == 0:
            notes.append(ex(tt, [0, 11, 3, 9][(i // 4 + bar) % 4], 4, ExtapDirection.IN_OUT))
        elif i % 4 == 2:
            notes.append(tap(tt, [2, 5, 7, 4][(i // 4 + bar) % 4], 4))
            notes.append(tap(tt, [10, 8, 11, 6][(i // 4 + bar) % 4], 4))
        elif peak and i % 2 == 1:
            notes.append(flick(tt, roam(i, bar, offset=3), 4, right=i % 4 == 1))
        else:
            notes.append(tap(tt, roam(i, bar, offset=7), 4))
    if peak:
        notes.append(air_tap(tick(bar, 0), 0, 4, AirDirection.UP_LEFT, ex_parent=True))
        notes.append(air_tap(tick(bar, 8), 12, 4, AirDirection.UP_RIGHT, ex_parent=True))


def chord_stairs(notes: list[ChartNote], bar: int, *, reverse: bool = False) -> None:
    pairs = [(0, 9), (3, 11), (6, 5), (10, 1)]
    if reverse:
        pairs = [(12 - a, 12 - b) for a, b in reversed(pairs)]
    for i, (a, b) in enumerate(pairs * 2):
        tt = tick(bar, i * 2, div=16)
        notes.append(ex(tt, a, 4, ExtapDirection.LEFT if reverse else ExtapDirection.RIGHT))
        notes.append(tap(tt, b, 4))
    notes.append(curve_slide(tick(bar, 0), tick(bar + 1, 0), 2 if reverse else 10, 11 if reverse else 1, 4, bend=-4 if reverse else 4))


def break_curve_section(notes: list[ChartNote], bar: int) -> None:
    notes.append(curve_slide(tick(bar, 0), tick(bar + 1, 0), 1, 11, 4, bend=3))
    notes.append(curve_slide(tick(bar, 4), tick(bar + 1, 4), 10, 2, 4, bend=-3))
    notes.append(air_curve(tick(bar, 8), tick(bar + 1, 8), 3, 9, 4, high=132))
    for unit, x in ((0, 1), (4, 11), (8, 5), (12, 8)):
        notes.append(ex(tick(bar, unit), x, 4, ExtapDirection.CENTER))


def finale_burst(notes: list[ChartNote], bar: int) -> None:
    lanes = [0, 2, 5, 9, 12, 7, 3, 10, 1, 6, 11, 4]
    for i in range(32):
        tt = tick(bar, i, div=32)
        x = lanes[(i + bar) % len(lanes)]
        if i % 8 in (0, 4):
            notes.append(ex(tt, x, 4, ExtapDirection.IN_OUT))
            notes.append(tap(tt, 12 - x, 4))
        elif i % 4 == 3:
            notes.append(flick(tt, x, 4, right=i % 8 < 4))
        else:
            notes.append(tap(tt, x, 4))


def four_panel_fill(notes: list[ChartNote], bar: int, *, dense: bool = False, mirror: bool = False) -> None:
    panels = [0, 3, 7, 11, 5, 9, 12, 2, 6, 10, 4, 8]
    if mirror:
        panels = [12 - x for x in reversed(panels)]
    for index, unit in enumerate(range(1, 16, 2)):
        if not dense and index % 2:
            continue
        x = panels[(index + bar) % len(panels)]
        if dense and index % 4 == 3:
            notes.append(flick(tick(bar, unit), x, 4, right=not mirror))
        elif index % 3 == 0:
            notes.append(ex(tick(bar, unit), x, 4, ExtapDirection.UP))
        else:
            notes.append(tap(tick(bar, unit), x, 4))
    if dense:
        for unit, left, right in ((2, 1, 10), (6, 5, 8), (10, 0, 7), (14, 4, 12)):
            if mirror:
                left, right = 12 - left, 12 - right
            notes.append(tap(tick(bar, unit), left, 4))
            notes.append(ex(tick(bar, unit), right, 4, ExtapDirection.CENTER))


def width_wave(notes: list[ChartNote], bar: int, *, reverse: bool = False) -> None:
    widths = [1, 2, 4, 7, 10, 12, 9, 5]
    anchors = [0, 2, 5, 4, 2, 0, 4, 9]
    if reverse:
        widths = list(reversed(widths))
        anchors = [LANES - x - w for x, w in zip(anchors, list(reversed(widths)), strict=True)]
    for i, (x, w) in enumerate(zip(anchors, widths, strict=True)):
        tt = tick(bar, i * 2, div=16)
        if w >= 9:
            notes.append(ex(tt, x, w, ExtapDirection.IN_OUT))
            notes.append(air_tap(tt, clamp_x(x + w // 3, min(4, w)), min(4, w), AirDirection.UP, ex_parent=True))
        elif w <= 2:
            notes.append(flick(tt, x, w, right=not reverse))
        else:
            notes.append(tap(tt, x, w))
    notes.append(width_slide(tick(bar, 0), tick(bar + 1, 0), 0 if not reverse else 12, 1, 2, 12))


def ice_wall(notes: list[ChartNote], bar: int, *, split: bool = False) -> None:
    if split:
        notes.append(ex(tick(bar, 0), 0, 7, ExtapDirection.LEFT))
        notes.append(ex(tick(bar, 0), 9, 7, ExtapDirection.RIGHT))
        notes.append(width_slide(tick(bar, 4), tick(bar, 12), 2, 12, 7, 2))
        notes.append(width_slide(tick(bar, 8), tick(bar + 1, 0), 2, 2, 0, 12))
    else:
        notes.append(ex(tick(bar, 0), 2, 12, ExtapDirection.IN_OUT))
        notes.append(hold(tick(bar, 2), tick(bar, 10), 0, 6))
        notes.append(hold(tick(bar, 2), tick(bar, 10), 10, 6))
        notes.append(width_slide(tick(bar, 8), tick(bar + 1, 0), 0, 12, 7, 2))
    for unit, x, w in ((3, 0, 1), (5, 15, 1), (7, 1, 2), (11, 13, 2), (14, 4, 8)):
        notes.append(flick(tick(bar, unit), x, w, right=unit % 2 == 1))


def aperture(notes: list[ChartNote], bar: int, *, opening: bool) -> None:
    specs = [(0, 12, 2), (2, 10, 3), (4, 8, 4), (6, 6, 5), (8, 4, 6), (10, 2, 7), (12, 1, 9), (14, 0, 12)]
    if opening:
        specs = list(reversed(specs))
    for unit, x, w in specs:
        tt = tick(bar, unit)
        direction = ExtapDirection.OUT_IN if opening else ExtapDirection.IN_OUT
        if w >= 8:
            notes.append(ex(tt, x, w, direction))
        else:
            notes.append(tap(tt, x, w))
    notes.append(air_curve(tick(bar, 0), tick(bar + 1, 0), 0 if opening else 12, 12 if opening else 0, 4, high=145))


def needle_to_wall(notes: list[ChartNote], bar: int, *, reverse: bool = False) -> None:
    for i in range(16):
        tt = tick(bar, i, div=16)
        grow = i if not reverse else 15 - i
        w = 1 + min(11, grow)
        x = clamp_x((i * 5) % 16 if not reverse else 15 - ((i * 5) % 16), w)
        if w in (1, 2, 3):
            notes.append(tap(tt, x, w))
        elif w >= 10:
            notes.append(ex(tt, x, w, ExtapDirection.IN_OUT))
        else:
            notes.append(flick(tt, x, w, right=not reverse))
    notes.append(width_slide(tick(bar, 0), tick(bar + 1, 0), 0 if not reverse else 4, 12, 15 if not reverse else 0, 1))


def frost_mirror(notes: list[ChartNote], bar: int, *, thaw: bool = False) -> None:
    left = [0, 1, 3, 6, 4, 2, 5, 7]
    right = [14, 13, 11, 8, 10, 12, 9, 7]
    if thaw:
        left, right = right, left
    for i in range(8):
        tt = tick(bar, i * 2, div=16)
        width = 1 + (i % 3 == 0)
        notes.append(tap(tt, left[i], width))
        notes.append(ex(tt, right[i], width, ExtapDirection.OUT_IN))
        if i in (1, 5):
            notes.append(air_tap(tt, 6 if i == 1 else 8, 4, AirDirection.UP, ex_parent=True))
    notes.append(air_hold_gate(tick(bar, 0), tick(bar + 1, 0), 4 if thaw else 8, 4, high=122))


def fractured_piano(notes: list[ChartNote], bar: int, *, invert: bool = False) -> None:
    phrase = [0, 5, 2, 9, 4, 13, 7, 10, 1, 12, 6, 14]
    if invert:
        phrase = [LANES - x - 1 for x in phrase]
    for i, x in enumerate(phrase):
        tt = tick(bar, i * 4, div=48)
        w = 1 if i % 4 in (1, 2) else 2
        if i % 6 == 5:
            notes.append(flick(tt, x, w, right=not invert))
        elif i % 3 == 0:
            notes.append(ex(tt, x, w, ExtapDirection.ROTATE_RIGHT if invert else ExtapDirection.ROTATE_LEFT))
        else:
            notes.append(tap(tt, x, w))
    notes.append(ribbon_slide(tick(bar, 0), tick(bar + 1, 0), 0 if invert else 13, 13 if invert else 0, phase=bar % 5))


def gravity_well(notes: list[ChartNote], bar: int, *, pull_right: bool) -> None:
    center = 10 if pull_right else 4
    for i in range(16):
        tt = tick(bar, i, div=16)
        spread = abs(7 - i)
        x = center + (spread % 5) * (1 if pull_right else -1)
        w = 1 if i % 2 else 3
        if i in (0, 4, 8, 12):
            notes.append(ex(tt, clamp_x(x, w), w, ExtapDirection.CENTER))
            notes.append(tap(tt, 0 if pull_right else 13, 3))
        elif i in (3, 7, 11, 15):
            notes.append(flick(tt, clamp_x(x, w), w, right=pull_right))
        else:
            notes.append(tap(tt, clamp_x(x, w), w))
    notes.append(zigzag_crush(tick(bar, 0), tick(bar + 1, 0), left_first=not pull_right, color=COLORS[bar % len(COLORS)]))


def snowfield_recovery(notes: list[ChartNote], bar: int, *, wide: bool = False) -> None:
    width = 6 if wide else 4
    left = 1 + (bar % 3)
    right = 15 - width - (bar % 4)
    notes.append(hold(tick(bar, 0), tick(bar + 1, 0), left, width))
    notes.append(hold(tick(bar, 0), tick(bar + 1, 0), right, width))
    for i, unit in enumerate((2, 5, 9, 13)):
        notes.append(ex(tick(bar, unit), roam(i, bar, offset=4), 4, ExtapDirection.UP))
    notes.append(air_curve(tick(bar, 8), tick(bar + 1, 8), 2 + bar % 3, 9 + bar % 2, 4, high=100 if wide else 130))


def spin_cascade(notes: list[ChartNote], bar: int, *, clockwise: bool) -> None:
    lanes = [1, 4, 8, 11, 7, 3, 10, 5]
    if not clockwise:
        lanes = [12 - x for x in reversed(lanes)]
    dirs = [ExtapDirection.ROTATE_RIGHT, ExtapDirection.RIGHT, ExtapDirection.IN_OUT, ExtapDirection.LEFT]
    for i in range(16):
        tt = tick(bar, i, div=16)
        x = lanes[i % len(lanes)]
        if i % 2 == 0:
            notes.append(ex(tt, x, 4, dirs[i % len(dirs)]))
        else:
            notes.append(flick(tt, clamp_x(x + (1 if clockwise else -1), 4), 4, right=clockwise))
    notes.append(ribbon_slide(tick(bar, 0), tick(bar, 8), 1, 10, w=4, phase=2))
    notes.append(ribbon_slide(tick(bar, 8), tick(bar + 1, 0), 9, 2, w=4, phase=0))


def build_events() -> tuple[list[TimelineSpeedEvent], list[NoteSpeedEvent]]:
    til = [
        TimelineSpeedEvent(0, tick(0, 0), 1.00),
        TimelineSpeedEvent(0, tick(16, 0), 1.08),
        TimelineSpeedEvent(0, tick(32, 0), 1.18),
        TimelineSpeedEvent(0, tick(44, 0), 0.72),
        TimelineSpeedEvent(0, tick(48, 0), 1.06),
        TimelineSpeedEvent(0, tick(56, 0), 1.24),
        TimelineSpeedEvent(0, tick(72, 0), 0.84),
        TimelineSpeedEvent(0, tick(76, 0), 1.12),
        TimelineSpeedEvent(0, tick(80, 0), 0.62),
        TimelineSpeedEvent(0, tick(82, 0), 1.00),
    ]
    for bar in (35, 39, 43, 63, 71, 79):
        til.append(TimelineSpeedEvent(0, tick(bar, 14), 1.85))
        til.append(TimelineSpeedEvent(0, tick(bar + 1, 0), 1.18 if bar < 72 else 1.00))
    note_speed = [
        NoteSpeedEvent(tick(0, 0), 1.00),
        NoteSpeedEvent(tick(16, 0), 1.08),
        NoteSpeedEvent(tick(32, 0), 1.15),
        NoteSpeedEvent(tick(44, 0), 0.90),
        NoteSpeedEvent(tick(56, 0), 1.20),
        NoteSpeedEvent(tick(72, 0), 0.95),
        NoteSpeedEvent(tick(80, 0), 0.80),
        NoteSpeedEvent(tick(82, 0), 1.00),
    ]
    return til, note_speed


def build_notes() -> list[ChartNote]:
    notes: list[ChartNote] = []

    for bar in range(0, 16):
        add_backbeat(notes, bar, strong=bar >= 12)
        piano_run(notes, bar, reverse=bar % 2 == 1, dense=bar >= 8)
        four_panel_fill(notes, bar, dense=bar >= 8, mirror=bar % 2 == 1)
        if bar in (4, 8, 12):
            frost_mirror(notes, bar, thaw=bar == 12)
        if bar in (6, 10, 14):
            fractured_piano(notes, bar, invert=bar % 4 == 2)
        if bar in (7, 15):
            width_wave(notes, bar, reverse=bar == 15)
        if bar % 4 == 3:
            notes.append(curve_slide(tick(bar, 8), tick(bar + 1, 0), 2, 12, 2, bend=5))

    for bar in range(16, 32):
        if bar % 2 == 0:
            split_jacks(notes, bar, mirror=(bar // 2) % 2 == 1)
        else:
            piano_run(notes, bar, reverse=bar % 4 == 1, dense=True)
            add_backbeat(notes, bar, strong=True)
        four_panel_fill(notes, bar, dense=True, mirror=bar % 4 in (1, 2))
        if bar % 4 == 1:
            fractured_piano(notes, bar, invert=bar % 8 == 5)
        if bar % 8 == 6:
            spin_cascade(notes, bar, clockwise=bar == 22)
        if bar in (19, 27):
            aperture(notes, bar, opening=bar == 27)
        if bar in (23, 31):
            ice_wall(notes, bar, split=bar == 31)
        if bar % 4 == 0:
            notes.append(air_curve(tick(bar, 0), tick(bar + 2, 0), 1, 13, 2, high=120))

    for bar in range(32, 44):
        drum_roll(notes, bar, peak=True)
        four_panel_fill(notes, bar, dense=True, mirror=bar % 2 == 1)
        if bar % 2 == 0:
            chord_stairs(notes, bar, reverse=(bar // 2) % 2 == 1)
        else:
            piano_run(notes, bar, reverse=bar % 4 == 3, dense=True)
        if bar in (33, 37, 41):
            gravity_well(notes, bar, pull_right=bar != 37)
        if bar in (34, 38, 42):
            spin_cascade(notes, bar, clockwise=bar == 38)
        if bar in (32, 36, 40):
            needle_to_wall(notes, bar, reverse=bar == 36)
        if bar in (35, 39, 43):
            notes.append(crush(tick(bar, 8), tick(bar + 1, 0), 1, 12, ColorValue.SKY))
            ice_wall(notes, bar, split=True)

    for bar in range(44, 48):
        break_curve_section(notes, bar)
        four_panel_fill(notes, bar, dense=False, mirror=bar % 2 == 0)
        snowfield_recovery(notes, bar, wide=bar % 2 == 0)
        if bar in (45, 47):
            aperture(notes, bar, opening=bar == 45)
        if bar == 47:
            finale_burst(notes, bar)

    for bar in range(48, 56):
        piano_run(notes, bar, reverse=bar % 2 == 0, dense=bar >= 52)
        four_panel_fill(notes, bar, dense=bar >= 52, mirror=bar % 2 == 0)
        notes.append(hold(tick(bar, 0), tick(bar, 8), roam(bar, bar, offset=2), 4))
        notes.append(slide(tick(bar, 8), tick(bar + 1, 0), roam(bar, bar, mirror=True, offset=5), roam(bar + 3, bar, offset=1), 4))
        add_backbeat(notes, bar, strong=bar >= 52)
        if bar % 4 == 0:
            frost_mirror(notes, bar, thaw=True)
        if bar % 4 == 2:
            fractured_piano(notes, bar, invert=True)
        if bar in (51, 55):
            width_wave(notes, bar, reverse=bar == 55)

    for bar in range(56, 72):
        if bar % 4 in (0, 1):
            finale_burst(notes, bar)
        elif bar % 4 == 2:
            chord_stairs(notes, bar, reverse=True)
            drum_roll(notes, bar, peak=True)
        else:
            split_jacks(notes, bar, mirror=True)
            piano_run(notes, bar, reverse=True, dense=True)
        four_panel_fill(notes, bar, dense=True, mirror=bar % 4 in (2, 3))
        if bar in (57, 61, 65, 69):
            gravity_well(notes, bar, pull_right=bar in (57, 65))
        if bar in (59, 63, 67, 71):
            spin_cascade(notes, bar, clockwise=bar in (63, 71))
        if bar in (56, 60, 64, 68):
            needle_to_wall(notes, bar, reverse=bar in (60, 68))
        if bar in (62, 70):
            ice_wall(notes, bar, split=True)
        if bar % 4 == 0:
            notes.append(air_curve(tick(bar, 0), tick(bar + 2, 0), 13, 1, 2, high=136))
        if bar % 8 == 7:
            notes.append(crush(tick(bar, 0), tick(bar + 1, 0), 12, 1, ColorValue.VIOLET))

    for bar in range(72, 76):
        break_curve_section(notes, bar)
        four_panel_fill(notes, bar, dense=False, mirror=bar % 2 == 1)
        snowfield_recovery(notes, bar, wide=bar in (72, 75))
        if bar in (73, 75):
            width_wave(notes, bar, reverse=bar == 75)
        add_backbeat(notes, bar, strong=bar == 75)

    for bar in range(76, 80):
        piano_run(notes, bar, reverse=bar % 2 == 1, dense=False)
        four_panel_fill(notes, bar, dense=True, mirror=bar % 2 == 1)
        notes.append(curve_slide(tick(bar, 0), tick(bar + 1, 0), 2, 12, 3, bend=3))
        if bar in (76, 78):
            fractured_piano(notes, bar, invert=bar == 78)
        if bar == 77:
            gravity_well(notes, bar, pull_right=False)
            aperture(notes, bar, opening=False)
        if bar == 78:
            needle_to_wall(notes, bar, reverse=True)
        if bar == 79:
            notes.append(crush(tick(bar, 8), tick(bar + 1, 0), 0, 13, ColorValue.PINK))
            ice_wall(notes, bar, split=False)

    notes.append(ex(tick(80, 0), 1, 4, ExtapDirection.IN_OUT))
    notes.append(ex(tick(80, 0), 10, 4, ExtapDirection.IN_OUT))
    four_panel_fill(notes, 80, dense=True)
    four_panel_fill(notes, 81, dense=True, mirror=True)
    aperture(notes, 80, opening=True)
    notes.append(air_tap(tick(80, 4), 4, 8, AirDirection.UP, ex_parent=True))
    notes.append(curve_slide(tick(80, 8), tick(81, 8), 2, 10, 4, bend=5))
    notes.append(width_slide(tick(81, 0), tick(82, 0), 1, 12, 7, 4))
    notes.append(air_curve(tick(81, 8), tick(82, 0), 9, 3, 4, high=140))
    notes.append(ex(tick(82, 0), 2, 12, ExtapDirection.IN_OUT))

    notes.sort(key=lambda note: (int(note.t), getattr(note, "x", 0), type(note).__name__))
    return notes


def summarize(
    notes: list[ChartNote],
    til_events: list[TimelineSpeedEvent],
    note_speed_events: list[NoteSpeedEvent],
) -> None:
    counts = Counter(type(note).__name__ for note in notes)
    last_tick = max(int(note.t) for note in notes)
    print(f"Generated {len(notes)} notes for Niflheimr ULTIMA 15.")
    print(f"BPM {BPM:g}, 4/4, bars 0-82, last tick {last_tick}.")
    for name, count in sorted(counts.items()):
        print(f"  {name:8s} {count}")
    widths = Counter(int(getattr(note, "w", 0)) for note in notes if hasattr(note, "w"))
    print("Top-level note widths:")
    for width, count in sorted(widths.items()):
        print(f"  w={width:<2d} {count}")
    x_mods = Counter(int(getattr(note, "x", 0)) % 4 for note in notes if hasattr(note, "x"))
    print("Top-level x modulo 4:")
    for mod, count in sorted(x_mods.items()):
        print(f"  x%4={mod} {count}")
    print(f"Generated {len(til_events)} timeline speed events.")
    print(f"Generated {len(note_speed_events)} note speed events.")


def validate(notes: list[ChartNote]) -> None:
    for note in notes:
        note.validate()


def push(
    notes: list[ChartNote],
    til_events: list[TimelineSpeedEvent],
    note_speed_events: list[NoteSpeedEvent],
) -> None:
    mg = Margrete()
    print(mg.status())
    with mg.open_edit(replace_all=True) as tx:
        tx.chart.events.bpm = [BpmEvent(0, BPM)]
        tx.chart.events.beat = [BeatEvent(0, 4, 4)]
        tx.chart.events.til = til_events
        tx.chart.events.note_speed = note_speed_events
        tx.chart.notes = notes
    print("Pushed Niflheimr ULTIMA 15 draft to Margrete.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Build Niflheimr ULTIMA 15 UMIGURI draft.")
    parser.add_argument("--push", action="store_true", help="Replace the open Margrete chart.")
    args = parser.parse_args()

    notes = build_notes()
    til_events, note_speed_events = build_events()
    validate(notes)
    summarize(notes, til_events, note_speed_events)
    if args.push:
        push(notes, til_events, note_speed_events)


if __name__ == "__main__":
    main()
