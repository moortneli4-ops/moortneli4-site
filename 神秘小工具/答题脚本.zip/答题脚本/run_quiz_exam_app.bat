@echo off
cd /d "%~dp0"
python "quiz_exam_app.py"
if errorlevel 1 (
  echo.
  echo Failed to launch quiz app. Please check Python environment.
  pause
)
