"""本地可交互答题程序。

功能：
- 上传统一格式 JSON 试题
- 自动读取题型、题型说明与答案
- 单选/多选点选，判断点选，填空输入（支持多空）
- 上一题 / 下一题 / 交卷
- 交卷后自动批改，并生成可复制的对错表

运行：python quiz_exam_app.py
"""

from __future__ import annotations

import json
import random
import tkinter as tk
from dataclasses import dataclass, field
from pathlib import Path
from tkinter import filedialog, messagebox
from typing import Any


TYPE_LABEL = {
    "single": "单选题",
    "multiple": "多选题",
    "judge": "判断题",
    "blank": "填空题",
    "subjective": "主观题",
}

TYPE_DEFAULT_HINT = {
    "single": "单选：只能选择 1 个选项。",
    "multiple": "多选：可选择多个选项，少选多选均算错。",
    "judge": "判断：选择“对”或“错”。",
    "blank": "填空：在输入框内填写答案，多个空请逐一填写。",
    "subjective": "主观：自由作答，不自动判分，仅展示你的答案与参考答案。",
}

TYPE_ALIAS = {
    "single": "single",
    "single_choice": "single",
    "radio": "single",
    "单选": "single",
    "multiple": "multiple",
    "multiple_choice": "multiple",
    "checkbox": "multiple",
    "多选": "multiple",
    "judge": "judge",
    "true_false": "judge",
    "tf": "judge",
    "判断": "judge",
    "blank": "blank",
    "fill": "blank",
    "fill_blank": "blank",
    "填空": "blank",
    "subjective": "subjective",
    "essay": "subjective",
    "qa": "subjective",
    "主观": "subjective",
    "简答": "subjective",
}

JUDGE_TRUE = {"对", "正确", "true", "t", "√", "yes", "y", "1"}
JUDGE_FALSE = {"错", "错误", "false", "f", "×", "x", "no", "n", "0"}
UNSELECTED_SENTINEL = "__UNSELECTED__"


@dataclass
class Question:
    qid: str
    qtype: str
    stem: str
    options: list[tuple[str, str]] = field(default_factory=list)
    # 选择/判断：答案为字符串列表；填空：答案为“每个空的候选列表”的列表；主观：参考答案列表
    answers: list[Any] = field(default_factory=list)
    explanation: str = ""


class ExamFormatError(Exception):
    pass


def normalize_type(raw: str) -> str:
    key = (raw or "").strip().lower()
    if key not in TYPE_ALIAS:
        raise ExamFormatError(f"不支持的题型：{raw}")
    return TYPE_ALIAS[key]


def parse_options(raw_options: Any) -> list[tuple[str, str]]:
    if isinstance(raw_options, dict):
        pairs = [(str(k).strip().upper(), str(v).strip()) for k, v in raw_options.items()]
    elif isinstance(raw_options, list):
        pairs = []
        for idx, item in enumerate(raw_options):
            label = chr(ord("A") + idx)
            pairs.append((label, str(item).strip()))
    else:
        raise ExamFormatError("`options` 必须是对象或数组。")

    pairs = [(k, v) for k, v in pairs if k and v]
    if len(pairs) < 2:
        raise ExamFormatError("选择题至少需要 2 个选项。")
    return pairs


def normalize_judge(value: Any) -> str:
    text = str(value).strip().lower()
    if text in JUDGE_TRUE:
        return "对"
    if text in JUDGE_FALSE:
        return "错"
    raise ExamFormatError(f"判断题答案无法识别：{value}")


def normalize_blank_answers(value: Any) -> list[list[str]]:
    """填空答案统一为：[[空1候选...], [空2候选...], ...]。"""
    if isinstance(value, str):
        return [[value.strip()]]
    if isinstance(value, list):
        if all(isinstance(v, list) for v in value):
            result = []
            for blank in value:
                cands = [str(x).strip() for x in blank if str(x).strip()]
                if not cands:
                    raise ExamFormatError("填空某个空的候选答案为空。")
                result.append(cands)
            return result
        # 一维列表：视为“单个空的多个候选答案”
        cands = [str(x).strip() for x in value if str(x).strip()]
        if not cands:
            raise ExamFormatError("填空答案为空。")
        return [cands]
    raise ExamFormatError("填空 `answer` 必须是字符串或数组。")


def normalize_choice_answers(value: Any) -> list[str]:
    if isinstance(value, str):
        items = [value]
    elif isinstance(value, list):
        items = [str(v) for v in value]
    else:
        raise ExamFormatError("`answer` 必须是字符串或数组。")
    cleaned = [x.strip().upper() for x in items if x.strip()]
    if not cleaned:
        raise ExamFormatError("选择题答案不能为空。")
    return cleaned


def normalize_subjective_answers(value: Any) -> list[str]:
    if isinstance(value, str):
        items = [value.strip()]
    elif isinstance(value, list):
        items = [str(v).strip() for v in value]
    else:
        raise ExamFormatError("主观题 `answer` 必须是字符串或数组。")
    cleaned = [x for x in items if x]
    if not cleaned:
        raise ExamFormatError("主观题参考答案不能为空。")
    return cleaned


def parse_question(raw: dict[str, Any], forced_type: str | None = None, idx: int = 1) -> Question:
    qtype = normalize_type(forced_type or str(raw.get("type", "")))
    qid = str(raw.get("id") or idx)
    stem = str(raw.get("stem") or raw.get("question") or "").strip()
    if not stem:
        raise ExamFormatError(f"第 {qid} 题缺少题干 `stem`。")

    explanation = str(raw.get("explanation", "")).strip()

    if qtype in {"single", "multiple"}:
        options = parse_options(raw.get("options"))
        answers: list[Any] = normalize_choice_answers(raw.get("answer"))
        return Question(qid, qtype, stem, options, answers, explanation)

    if qtype == "judge":
        answers = [normalize_judge(raw.get("answer"))]
        return Question(qid, qtype, stem, [], answers, explanation)

    if qtype == "subjective":
        answers = normalize_subjective_answers(raw.get("answer"))
        return Question(qid, qtype, stem, [], answers, explanation)

    # blank
    answers = normalize_blank_answers(raw.get("answer"))
    return Question(qid, qtype, stem, [], answers, explanation)


def load_exam(path: Path) -> tuple[str, dict[str, str], list[Question]]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ExamFormatError(f"JSON 解析失败：{exc}") from exc

    if not isinstance(data, dict):
        raise ExamFormatError("根节点必须是 JSON 对象。")

    title = str(data.get("title") or "未命名试卷")

    hints = dict(TYPE_DEFAULT_HINT)
    hints_raw = data.get("type_instructions", {})
    if isinstance(hints_raw, dict):
        for key, val in hints_raw.items():
            mapped = TYPE_ALIAS.get(str(key).strip().lower())
            if mapped:
                hints[mapped] = str(val)

    questions: list[Question] = []

    if isinstance(data.get("questions"), list):
        for i, item in enumerate(data["questions"], start=1):
            if not isinstance(item, dict):
                raise ExamFormatError(f"第 {i} 题必须是对象。")
            questions.append(parse_question(item, idx=i))
    else:
        section_map = [
            ("single", ["single", "single_choice", "单选"]),
            ("multiple", ["multiple", "multiple_choice", "多选"]),
            ("judge", ["judge", "true_false", "判断"]),
            ("blank", ["blank", "fill", "fill_blank", "填空"]),
            ("subjective", ["subjective", "essay", "qa", "主观", "简答"]),
        ]
        idx = 1
        for qtype, keys in section_map:
            block = None
            for key in keys:
                if isinstance(data.get(key), list):
                    block = data[key]
                    break
            if block is None:
                continue
            for item in block:
                if not isinstance(item, dict):
                    raise ExamFormatError(f"第 {idx} 题必须是对象。")
                questions.append(parse_question(item, forced_type=qtype, idx=idx))
                idx += 1

    if not questions:
        raise ExamFormatError("没有读取到题目。请提供 `questions` 数组或分题型数组。")

    return title, hints, questions


def normalize_text(s: str) -> str:
    return " ".join(str(s).strip().lower().split())


def grade_one(q: Question, user_answer: Any) -> bool | None:
    if q.qtype == "subjective":
        return None
    if q.qtype == "single":
        return str(user_answer or "").strip().upper() == q.answers[0]
    if q.qtype == "multiple":
        if not isinstance(user_answer, list):
            return False
        user_set = {str(x).strip().upper() for x in user_answer if str(x).strip()}
        return user_set == set(q.answers)
    if q.qtype == "judge":
        return str(user_answer or "").strip() == q.answers[0]
    # blank：逐空匹配，每空命中任一候选即可
    if not isinstance(user_answer, list):
        return False
    if len(user_answer) != len(q.answers):
        return False
    for filled, candidates in zip(user_answer, q.answers):
        norm = normalize_text(filled)
        if not any(norm == normalize_text(c) for c in candidates):
            return False
    return True


class QuizApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("交互答题程序（单选 / 多选 / 判断 / 填空）")
        self.root.geometry("1000x780")

        self.exam_title = ""
        self.type_hints = dict(TYPE_DEFAULT_HINT)
        self.questions: list[Question] = []
        self.filtered_question_indices: list[int] = []
        self.display_order: list[int] = []
        self.current_display_index = 0
        self.random_remaining_indices: list[int] = []
        self.user_answers: list[Any] = []
        self.realtime_review_var = tk.BooleanVar(value=False)
        self.random_order_var = tk.BooleanVar(value=False)
        self.show_unanswered_var = tk.BooleanVar(value=False)
        self.only_wrong_var = tk.BooleanVar(value=True)
        self.type_filter_vars = {qtype: tk.BooleanVar(value=True) for qtype in TYPE_LABEL}
        self.realtime_report_active = False
        self.realtime_skip_allowed_question_idx: int | None = None

        self.single_var = tk.StringVar(value=UNSELECTED_SENTINEL)
        self.judge_var = tk.StringVar(value=UNSELECTED_SENTINEL)
        self.multi_vars: dict[str, tk.BooleanVar] = {}
        self.blank_entries: list[tk.Entry] = []
        self.subjective_text: tk.Text | None = None

        self._build_ui()

    def _build_ui(self):
        top = tk.Frame(self.root)
        top.pack(fill="x", padx=12, pady=10)

        tk.Button(top, text="上传试题 JSON", command=self.on_upload, width=16).pack(side="left")
        self.file_label = tk.Label(top, text="未加载试卷", anchor="w", fg="#666")
        self.file_label.pack(side="left", padx=10, fill="x", expand=True)
        tk.Checkbutton(
            top, text="实时批改", variable=self.realtime_review_var, command=self.on_realtime_toggle
        ).pack(side="right", padx=(8, 0))
        tk.Checkbutton(
            top, text="随机题序", variable=self.random_order_var, command=self.on_random_order_toggle
        ).pack(side="right")

        type_filter_row = tk.Frame(self.root)
        type_filter_row.pack(fill="x", padx=12, pady=(0, 6))
        tk.Label(type_filter_row, text="出现题型：", font=("Microsoft YaHei", 10, "bold")).pack(side="left")
        for qtype in ("single", "multiple", "judge", "blank", "subjective"):
            tk.Checkbutton(
                type_filter_row,
                text=TYPE_LABEL[qtype],
                variable=self.type_filter_vars[qtype],
                command=self.on_type_filter_change,
            ).pack(side="left", padx=(4, 0))

        self.title_label = tk.Label(
            self.root, text="请先上传试题 JSON", font=("Microsoft YaHei", 14, "bold")
        )
        self.title_label.pack(anchor="w", padx=12)

        info = tk.Frame(self.root)
        info.pack(fill="x", padx=12, pady=(4, 0))
        self.progress_label = tk.Label(info, text="", font=("Microsoft YaHei", 10))
        self.progress_label.pack(side="left")
        self.type_label = tk.Label(info, text="", font=("Microsoft YaHei", 10, "bold"), fg="#1565C0")
        self.type_label.pack(side="left", padx=16)

        self.hint_label = tk.Label(self.root, text="", fg="#555", anchor="w", justify="left")
        self.hint_label.pack(anchor="w", padx=12, pady=(2, 8))

        self.stem_text = tk.Text(self.root, height=5, wrap="word", font=("Microsoft YaHei", 11))
        self.stem_text.pack(fill="x", padx=12)
        self.stem_text.configure(state="disabled", bg="#FAFAFA")

        self.answer_frame = tk.Frame(self.root, bd=1, relief="groove")
        self.answer_frame.pack(fill="both", expand=False, padx=12, pady=10, ipady=6)

        nav = tk.Frame(self.root)
        nav.pack(fill="x", padx=12)
        tk.Button(nav, text="上一题", command=self.prev_question, width=10).pack(side="left")
        tk.Button(nav, text="下一题", command=self.next_question, width=10).pack(side="left", padx=8)
        tk.Button(
            nav, text="交卷批改", command=self.submit_exam, width=12, bg="#2E7D32", fg="white"
        ).pack(side="left", padx=8)
        tk.Checkbutton(
            nav, text="显示未作答题目", variable=self.show_unanswered_var
        ).pack(side="left", padx=(4, 0))
        tk.Checkbutton(
            nav, text="仅显示错题", variable=self.only_wrong_var
        ).pack(side="left", padx=(4, 0))
        self.status_label = tk.Label(nav, text="", fg="#B71C1C")
        self.status_label.pack(side="left", padx=10)

        report_top = tk.Frame(self.root)
        report_top.pack(fill="x", padx=12, pady=(12, 4))
        tk.Label(
            report_top, text="批改结果（可复制发给老师/助教讲解）", font=("Microsoft YaHei", 11, "bold")
        ).pack(side="left")
        tk.Button(report_top, text="复制结果", command=self.copy_report, width=10).pack(side="right")

        self.report_text = tk.Text(self.root, height=15, wrap="none", font=("Consolas", 10))
        self.report_text.pack(fill="both", expand=True, padx=12, pady=(0, 12))

    def set_stem(self, text: str):
        self.stem_text.configure(state="normal")
        self.stem_text.delete("1.0", "end")
        self.stem_text.insert("1.0", text)
        self.stem_text.configure(state="disabled")

    def clear_answer_widgets(self):
        for child in self.answer_frame.winfo_children():
            child.destroy()
        self.multi_vars.clear()
        self.blank_entries.clear()
        self.subjective_text = None

    def on_upload(self):
        file_path = filedialog.askopenfilename(
            title="选择试题 JSON",
            filetypes=[("JSON 试题", "*.json"), ("所有文件", "*.*")],
        )
        if not file_path:
            return
        try:
            title, hints, questions = load_exam(Path(file_path))
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("加载失败", str(exc))
            return

        self.exam_title = title
        self.type_hints = hints
        self.questions = questions
        self.user_answers = [None] * len(questions)
        for var in self.type_filter_vars.values():
            var.set(True)
        self.refresh_filtered_questions(reset_position=True)
        self.reset_display_order()

        self.file_label.configure(text=file_path)
        self.title_label.configure(text=f"试卷：{self.exam_title}")
        self.status_label.configure(text="")
        self.report_text.delete("1.0", "end")
        self.realtime_report_active = False
        self.realtime_skip_allowed_question_idx = None
        self.render_current_question()

    def reset_display_order(self):
        self.random_remaining_indices = []
        if not self.filtered_question_indices:
            self.display_order = []
            self.current_display_index = 0
            return
        if self.random_order_var.get():
            all_indices = list(self.filtered_question_indices)
            first_idx = random.choice(all_indices)
            self.display_order = [first_idx]
            self.random_remaining_indices = [idx for idx in all_indices if idx != first_idx]
            random.shuffle(self.random_remaining_indices)
        else:
            self.display_order = list(self.filtered_question_indices)
        self.current_display_index = 0

    def get_current_question_index(self) -> int:
        return self.display_order[self.current_display_index]

    def refresh_filtered_questions(self, reset_position: bool = False):
        enabled_types = {qtype for qtype, var in self.type_filter_vars.items() if var.get()}
        self.filtered_question_indices = [
            idx for idx, q in enumerate(self.questions) if q.qtype in enabled_types
        ]
        if reset_position:
            self.current_display_index = 0

    def clear_realtime_report(self):
        if self.realtime_report_active:
            self.report_text.delete("1.0", "end")
            self.realtime_report_active = False

    def is_answer_empty(self, q: Question, ans: Any) -> bool:
        if ans is None:
            return True
        if q.qtype == "multiple":
            return not isinstance(ans, list) or len(ans) == 0
        if q.qtype == "blank":
            return not isinstance(ans, list) or not any(str(x).strip() for x in ans)
        if q.qtype == "subjective":
            return not str(ans or "").strip()
        return not str(ans).strip()

    def can_realtime_grade(self, q: Question, ans: Any) -> bool:
        if self.is_answer_empty(q, ans):
            return False
        if q.qtype == "blank":
            return isinstance(ans, list) and all(str(x).strip() for x in ans) and len(ans) == len(q.answers)
        return True

    def show_realtime_error(self, q: Question, ans: Any):
        lines = [
            f"第 {self.current_display_index + 1} 题（题号 {q.qid}）实时批改：错误",
            f"你的答案：{self.format_user_answer(q, ans)}",
            f"正确答案：{self.format_correct_answer(q)}",
        ]
        if q.explanation:
            lines.append(f"解析：{q.explanation}")
        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", "\n".join(lines))
        self.realtime_report_active = True

    def on_answer_changed(self):
        # 实时批改改为“点击下一题时触发”，作答过程中不即时显示结果。
        if self.realtime_review_var.get():
            self.realtime_skip_allowed_question_idx = None
            self.clear_realtime_report()

    def on_realtime_toggle(self):
        if not self.realtime_review_var.get():
            self.clear_realtime_report()

    def on_random_order_toggle(self):
        if not self.questions:
            return
        self.save_current_answer()
        self.reset_display_order()
        self.status_label.configure(
            text=f"已切换为{'随机题序' if self.random_order_var.get() else '原题序'}，已从第 1 题开始。",
            fg="#1565C0",
        )
        self.realtime_skip_allowed_question_idx = None
        self.clear_realtime_report()
        self.render_current_question()

    def on_type_filter_change(self):
        enabled_types = [qtype for qtype, var in self.type_filter_vars.items() if var.get()]
        if not enabled_types:
            messagebox.showinfo("提示", "至少需要勾选 1 种题型。")
            for var in self.type_filter_vars.values():
                var.set(True)
            enabled_types = list(self.type_filter_vars.keys())

        if not self.questions:
            return

        self.save_current_answer()
        self.refresh_filtered_questions(reset_position=True)
        self.reset_display_order()
        self.realtime_skip_allowed_question_idx = None
        self.clear_realtime_report()
        if not self.filtered_question_indices:
            self.status_label.configure(text="当前试卷中没有你勾选的题型。", fg="#B71C1C")
            self.progress_label.configure(text="第 0 / 0 题")
            self.type_label.configure(text="")
            self.hint_label.configure(text="")
            self.set_stem("当前筛选条件下无题目。")
            self.clear_answer_widgets()
            return
        self.status_label.configure(
            text=f"已筛选题型：{len(self.filtered_question_indices)} 题", fg="#1565C0"
        )
        self.render_current_question()

    def save_current_answer(self):
        if not self.questions or not self.display_order:
            return
        q_idx = self.get_current_question_index()
        q = self.questions[q_idx]
        if q.qtype == "single":
            raw = self.single_var.get().strip().upper()
            self.user_answers[q_idx] = None if raw in {"", UNSELECTED_SENTINEL} else raw
        elif q.qtype == "judge":
            raw = self.judge_var.get().strip()
            self.user_answers[q_idx] = None if raw in {"", UNSELECTED_SENTINEL} else raw
        elif q.qtype == "multiple":
            self.user_answers[q_idx] = [k for k, v in self.multi_vars.items() if v.get()]
        elif q.qtype == "subjective":
            if self.subjective_text is None:
                self.user_answers[q_idx] = ""
            else:
                self.user_answers[q_idx] = self.subjective_text.get("1.0", "end").strip()
        else:
            self.user_answers[q_idx] = [e.get().strip() for e in self.blank_entries]

    def render_current_question(self):
        if not self.questions or not self.display_order:
            return
        q_idx = self.get_current_question_index()
        q = self.questions[q_idx]
        total = len(self.filtered_question_indices)
        self.progress_label.configure(text=f"第 {self.current_display_index + 1} / {total} 题")
        self.type_label.configure(text=f"题型：{TYPE_LABEL[q.qtype]}")
        self.hint_label.configure(text=f"题型说明：{self.type_hints.get(q.qtype, '')}")
        self.set_stem(f"{q.qid}. {q.stem}")

        self.clear_answer_widgets()
        saved = self.user_answers[q_idx]

        if q.qtype == "single":
            self.single_var.set(saved or UNSELECTED_SENTINEL)
            for label, text in q.options:
                tk.Radiobutton(
                    self.answer_frame, text=f"{label}. {text}", variable=self.single_var,
                    value=label, anchor="w", justify="left", font=("Microsoft YaHei", 11),
                    wraplength=920, command=self.on_answer_changed,
                ).pack(fill="x", padx=10, pady=3)

        elif q.qtype == "judge":
            self.judge_var.set(saved or UNSELECTED_SENTINEL)
            for label in ("对", "错"):
                tk.Radiobutton(
                    self.answer_frame, text=label, variable=self.judge_var, value=label,
                    anchor="w", font=("Microsoft YaHei", 12), command=self.on_answer_changed,
                ).pack(fill="x", padx=10, pady=4)

        elif q.qtype == "multiple":
            selected_set = set(saved or [])
            for label, text in q.options:
                var = tk.BooleanVar(value=label in selected_set)
                self.multi_vars[label] = var
                tk.Checkbutton(
                    self.answer_frame, text=f"{label}. {text}", variable=var, anchor="w",
                    justify="left", font=("Microsoft YaHei", 11), wraplength=920,
                    command=self.on_answer_changed,
                ).pack(fill="x", padx=10, pady=3)

        elif q.qtype == "subjective":
            tk.Label(
                self.answer_frame,
                text="请自由作答（本题不自动批改，交卷后会展示你的答案和参考答案）：",
                font=("Microsoft YaHei", 11),
                anchor="w",
                justify="left",
            ).pack(fill="x", padx=10, pady=(8, 4))
            self.subjective_text = tk.Text(
                self.answer_frame, height=8, wrap="word", font=("Microsoft YaHei", 11)
            )
            self.subjective_text.pack(fill="both", expand=True, padx=10, pady=(0, 8))
            if isinstance(saved, str) and saved.strip():
                self.subjective_text.insert("1.0", saved.strip())

        else:  # blank
            num_blanks = len(q.answers)
            saved_list = saved if isinstance(saved, list) else []
            tk.Label(
                self.answer_frame, text=f"请输入答案（共 {num_blanks} 个空）：",
                font=("Microsoft YaHei", 11), anchor="w",
            ).pack(fill="x", padx=10, pady=(10, 4))
            for i in range(num_blanks):
                row = tk.Frame(self.answer_frame)
                row.pack(fill="x", padx=10, pady=3)
                tk.Label(row, text=f"空{i + 1}：", font=("Microsoft YaHei", 11)).pack(side="left")
                entry = tk.Entry(row, font=("Microsoft YaHei", 12))
                entry.pack(side="left", fill="x", expand=True)
                if i < len(saved_list):
                    entry.insert(0, saved_list[i])
                entry.bind("<KeyRelease>", lambda _e: self.on_answer_changed())
                self.blank_entries.append(entry)

    def prev_question(self):
        if not self.questions or not self.display_order:
            return
        self.save_current_answer()
        if self.current_display_index > 0:
            self.current_display_index -= 1
            self.realtime_skip_allowed_question_idx = None
            self.render_current_question()

    def next_question(self):
        if not self.questions or not self.display_order:
            return
        self.save_current_answer()

        if self.realtime_review_var.get():
            q_idx = self.get_current_question_index()
            q = self.questions[q_idx]
            ans = self.user_answers[q_idx]
            if q.qtype != "subjective":
                ok = grade_one(q, ans)
                if not ok:
                    if self.realtime_skip_allowed_question_idx == q_idx:
                        pass
                    else:
                        self.show_realtime_error(q, ans)
                        self.realtime_skip_allowed_question_idx = q_idx
                        self.status_label.configure(
                            text="当前题答案错误，再点一次下一题可跳过并保留该题批改结果。",
                            fg="#B71C1C",
                        )
                        return
                else:
                    self.realtime_skip_allowed_question_idx = None

        if self.random_order_var.get():
            if self.current_display_index < len(self.display_order) - 1:
                self.current_display_index += 1
                self.status_label.configure(text="")
                self.render_current_question()
                return
            if self.random_remaining_indices:
                next_idx = self.random_remaining_indices.pop()
                self.display_order.append(next_idx)
                self.current_display_index += 1
                self.status_label.configure(text="")
                self.render_current_question()
                return
            self.status_label.configure(text="已是最后一题，可点击交卷批改。")
            return

        if self.current_display_index < len(self.display_order) - 1:
            self.current_display_index += 1
            self.status_label.configure(text="")
            self.render_current_question()
        else:
            self.status_label.configure(text="已是最后一题，可点击交卷批改。")

    def format_user_answer(self, q: Question, ans: Any) -> str:
        if ans is None:
            return "（未作答）"
        if q.qtype == "multiple":
            return ",".join(sorted(str(x).upper() for x in ans)) if ans else "（未作答）"
        if q.qtype == "blank":
            if not isinstance(ans, list) or not any(str(x).strip() for x in ans):
                return "（未作答）"
            return " | ".join(x if x else "（空）" for x in ans)
        if q.qtype == "subjective":
            text = str(ans or "").strip()
            return text if text else "（未作答）"
        return str(ans)

    def format_correct_answer(self, q: Question) -> str:
        if q.qtype == "multiple":
            return ",".join(sorted(q.answers))
        if q.qtype == "blank":
            return " | ".join("/".join(cands) for cands in q.answers)
        if q.qtype == "subjective":
            return " / ".join(str(x) for x in q.answers)
        return q.answers[0]

    def submit_exam(self):
        if not self.questions or not self.filtered_question_indices:
            messagebox.showinfo("提示", "请先上传试卷。")
            return
        self.save_current_answer()

        lines = [f"试卷：{self.exam_title}", "题号\t题型\t你的答案\t正确答案\t结果"]
        total_correct = 0
        total_wrong_ids: list[str] = []
        total_auto_count = 0
        total_subjective_count = 0

        # 统计口径与“显示过滤”分离：成绩始终按当前筛选题型的全量题目计算。
        for idx in self.filtered_question_indices:
            q = self.questions[idx]
            ans = self.user_answers[idx]
            if q.qtype == "subjective":
                total_subjective_count += 1
                continue
            total_auto_count += 1
            ok = grade_one(q, ans)
            if ok:
                total_correct += 1
            else:
                total_wrong_ids.append(q.qid)

        shown_count = 0
        for idx in self.filtered_question_indices:
            q = self.questions[idx]
            ans = self.user_answers[idx]
            if (not self.show_unanswered_var.get()) and self.is_answer_empty(q, ans):
                continue
            if self.only_wrong_var.get():
                if q.qtype == "subjective":
                    continue
                if grade_one(q, ans):
                    continue
            shown_count += 1
            if q.qtype == "subjective":
                lines.append(
                    f"{q.qid}\t{TYPE_LABEL[q.qtype]}\t{self.format_user_answer(q, ans)}\t"
                    f"{self.format_correct_answer(q)}\t主观题（不自动批改）"
                )
                continue
            ok = grade_one(q, ans)
            lines.append(
                f"{q.qid}\t{TYPE_LABEL[q.qtype]}\t{self.format_user_answer(q, ans)}\t"
                f"{self.format_correct_answer(q)}\t{'正确' if ok else '错误'}"
            )

        total = len(self.filtered_question_indices)
        score = total_correct / total_auto_count * 100 if total_auto_count else 0
        lines.append("")
        if shown_count == 0:
            lines.append("当前筛选下暂无可显示题目（未勾选“显示未作答题目”且尚未作答）。")
        lines.append(
            f"汇总显示题目：{shown_count}（{('含' if self.show_unanswered_var.get() else '不含')}未作答）"
        )
        lines.append(
            f"总题数：{total}（自动批改题：{total_auto_count}，主观题：{total_subjective_count}）"
        )
        lines.append(
            f"自动批改答对：{total_correct}    自动批改答错：{total_auto_count - total_correct}"
        )
        lines.append(f"自动批改正确率：{score:.2f}%")
        if total_wrong_ids:
            lines.append(f"错题题号：{', '.join(total_wrong_ids)}")

        report = "\n".join(lines)
        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", report)
        self.status_label.configure(
            text=f"已批改：自动题 {total_correct}/{total_auto_count}（{score:.2f}%），主观题 {total_subjective_count} 题",
            fg="#2E7D32",
        )

    def copy_report(self):
        text = self.report_text.get("1.0", "end").strip()
        if not text:
            messagebox.showinfo("提示", "暂无可复制内容，请先交卷批改。")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()
        messagebox.showinfo("已复制", "批改结果已复制到剪贴板，可直接粘贴发给我做讲解。")


def main():
    root = tk.Tk()
    QuizApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
