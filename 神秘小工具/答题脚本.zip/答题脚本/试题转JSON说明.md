# 如何把试题转换为答题脚本可用 JSON

本说明用于让你或后续大模型把任意学科试卷（Word/PDF/Markdown）转换为 `quiz_exam_app.py` 可直接加载的 JSON。

---

## 1) 顶层结构（推荐）

```json
{
  "title": "试卷标题",
  "type_instructions": {
    "single": "单选说明",
    "multiple": "多选说明",
    "judge": "判断说明",
    "blank": "填空说明",
    "subjective": "主观题说明"
  },
  "questions": [
    {
      "id": "1",
      "type": "single",
      "stem": "题干",
      "options": {
        "A": "选项A",
        "B": "选项B",
        "C": "选项C",
        "D": "选项D"
      },
      "answer": "B",
      "explanation": "可选，解析"
    }
  ]
}
```

---

## 2) 每种题型的字段规范

### A. 单选 `single`

```json
{
  "id": "1",
  "type": "single",
  "stem": "监督学习的特点是？",
  "options": {"A":"有标签","B":"无标签","C":"不需要损失","D":"只用于聚类"},
  "answer": "A",
  "explanation": "监督学习使用带标签样本。"
}
```

- `answer` 必须是一个选项字母（如 `"A"`）

### B. 多选 `multiple`

```json
{
  "id": "2",
  "type": "multiple",
  "stem": "以下哪些属于目标检测评价指标？",
  "options": {"A":"IoU","B":"Precision","C":"Recall","D":"Learning Rate"},
  "answer": ["A", "B", "C"]
}
```

- `answer` 必须是数组
- 自动判分为**全对才得分**

### C. 判断 `judge`

```json
{
  "id": "3",
  "type": "judge",
  "stem": "池化层通常不引入可训练参数。",
  "answer": "对"
}
```

- 兼容 `对/错`、`true/false` 等常见写法

### D. 填空 `blank`

单空：

```json
{
  "id": "4",
  "type": "blank",
  "stem": "YOLO 输出公式中的 C 表示______。",
  "answer": ["类别数", "C"]
}
```

多空：

```json
{
  "id": "5",
  "type": "blank",
  "stem": "线性回归可写为 y = ___ * x + ___。",
  "answer": [["w","权重"],["b","偏置"]]
}
```

- 单空：`answer` 是字符串或一维数组（多个同义答案）
- 多空：`answer` 是二维数组，每个空一组候选答案

### E. 主观 `subjective`（新增）

```json
{
  "id": "6",
  "type": "subjective",
  "stem": "请解释过拟合并给出两种缓解方案。",
  "answer": [
    "过拟合是训练集表现好但泛化差。",
    "缓解方法：数据增强、正则化、早停、Dropout、减小模型复杂度等。"
  ],
  "explanation": "主观题不自动判分。"
}
```

- `answer` 可为字符串或数组（用于参考答案）
- 程序会展示「你的答案」与「参考答案」，但**不自动判对错**

---

## 3) 转换时常见坑

- 必须是合法 JSON（双引号、逗号、括号完整）
- `type` 必须是：`single` / `multiple` / `judge` / `blank` / `subjective`
- 选择题必须有 `options`
- 多选 `answer` 必须是数组，不要写成 `"ABC"`
- 主观题不要期待自动判分

---

## 4) 给大模型的转换提示词（可直接复制）

把下面整段发给大模型，并附上你的原始试卷内容：

```text
请把我给你的试卷文本转换成严格合法的 JSON，供 quiz_exam_app.py 使用。
要求：
1) 顶层字段必须包含：title、type_instructions、questions。
2) 题型只允许：single、multiple、judge、blank、subjective。
3) single/multiple 必须有 options（A/B/C/D...）与 answer。
4) multiple 的 answer 必须是数组，如 ["A","C"]。
5) blank：
   - 单空可写 answer: ["答案1","答案2"]；
   - 多空必须写二维数组，如 [["w","权重"],["b","偏置"]]。
6) subjective 不自动判分，answer 写参考答案（字符串或数组均可）。
7) 每题包含：id、type、stem，可选 explanation。
8) 返回时只输出 JSON，不要附加解释文字。
```

---

## 5) 快速验证

转换后先在答题程序里加载 JSON，若能正常显示并可交卷，则格式正确。
