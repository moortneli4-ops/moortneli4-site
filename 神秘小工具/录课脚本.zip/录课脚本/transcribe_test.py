﻿from pathlib import Path
import argparse

from faster_whisper import WhisperModel


def parse_args():
    parser = argparse.ArgumentParser(
        description="Transcribe one audio file to plain text (no timestamps)."
    )
    parser.add_argument("audio_path", help="Path to input audio file, e.g. 1.wav")
    parser.add_argument(
        "--output",
        dest="output_path",
        default=None,
        help="Output txt path. If not set, auto-generate beside audio file.",
    )
    parser.add_argument(
        "--model",
        dest="model_size",
        default="small",
        help="Whisper model size: tiny/base/small/medium/large-v3",
    )
    return parser.parse_args()


def build_default_output(audio_path: Path) -> Path:
    return audio_path.with_name(f"{audio_path.stem}_transcript.txt")


def main():
    args = parse_args()
    audio_path = Path(args.audio_path).expanduser().resolve()
    if not audio_path.exists():
        raise FileNotFoundError(f"Input file not found: {audio_path}")

    output_path = (
        Path(args.output_path).expanduser().resolve()
        if args.output_path
        else build_default_output(audio_path)
    )

    model = WhisperModel(args.model_size, device="cpu", compute_type="int8")
    segments, _ = model.transcribe(
        str(audio_path), language="zh", vad_filter=True, beam_size=5
    )

    with open(output_path, "w", encoding="utf-8") as f:
        for seg in segments:
            text = seg.text.strip()
            if text:
                f.write(text + "\n")

    print("Done:", output_path)


if __name__ == "__main__":
    main()
