# 录课文字提取脚本（可跨学科复用）

本目录用于把课程视频/音频转成文字，适用于任意学科（数学、英语、专业课等）。

## 文件说明

- `setup_env.ps1`：一键安装/检查 Python、FFmpeg、faster-whisper
- `video_to_text_gui.py`：图形界面版（选视频 -> 转文字 -> 预览保存）
- `run_video_to_text_gui.bat`：双击启动 GUI
- `transcribe_test.py`：命令行版（适合批处理）

## 首次使用

1. 在 PowerShell 进入本目录。
2. 运行：
   - `Set-ExecutionPolicy -Scope Process Bypass`
   - `.\setup_env.ps1`
3. 环境准备完成后，双击 `run_video_to_text_gui.bat`。

## 命令行快速用法（可批量）

- 基本：
  - `python transcribe_test.py "D:\course\lesson1.wav"`
- 指定输出：
  - `python transcribe_test.py "D:\course\lesson1.wav" --output "D:\course\lesson1.txt"`
- 指定模型：
  - `python transcribe_test.py "D:\course\lesson1.wav" --model small`

## 跨学科建议

- 理工科：优先使用 `small/medium` 模型，术语识别更稳。
- 语言类课程：尽量保证原始音频清晰，减少回声和噪声。
- 多段录课：建议每节课单独命名，便于后续总结考点。
