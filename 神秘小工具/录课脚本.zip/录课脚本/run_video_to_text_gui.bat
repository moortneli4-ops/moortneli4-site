@echo off
cd /d "%~dp0"
python "video_to_text_gui.py"
if errorlevel 1 (
  echo.
  echo Failed to launch GUI. Please check Python environment.
  pause
)
