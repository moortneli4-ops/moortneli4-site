param(
    [switch]$SkipPythonInstall,
    [switch]$SkipFfmpegInstall
)

$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Test-CommandExists {
    param([string]$CommandName)
    return [bool](Get-Command $CommandName -ErrorAction SilentlyContinue)
}

function Refresh-Path {
    $machinePath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"
}

function Assert-Winget {
    if (-not (Test-CommandExists "winget")) {
        throw "winget not found. Please install/update Microsoft App Installer first."
    }
}

function Install-PythonIfNeeded {
    if ($SkipPythonInstall) {
        Write-Host "Skip Python install (-SkipPythonInstall)." -ForegroundColor Yellow
        return
    }

    if (Test-CommandExists "python") {
        Write-Host "Python found:" -ForegroundColor Green
        python --version
        return
    }

    Write-Step "Python not found, installing Python 3.11 with winget"
    Assert-Winget
    winget install -e --id Python.Python.3.11 --accept-package-agreements --accept-source-agreements

    Write-Step "Refreshing PATH in current shell"
    Refresh-Path

    if (-not (Test-CommandExists "python")) {
        throw "Python still not found. Reopen PowerShell and run the script again."
    }

    Write-Host "Python installed:" -ForegroundColor Green
    python --version
}

function Install-FFmpegIfNeeded {
    if ($SkipFfmpegInstall) {
        Write-Host "Skip FFmpeg install (-SkipFfmpegInstall)." -ForegroundColor Yellow
        return
    }

    if (Test-CommandExists "ffmpeg") {
        Write-Host "FFmpeg found:" -ForegroundColor Green
        ffmpeg -version | Select-Object -First 1
        return
    }

    Write-Step "FFmpeg not found, installing Gyan.FFmpeg with winget"
    Assert-Winget
    winget install -e --id Gyan.FFmpeg --accept-package-agreements --accept-source-agreements

    Write-Step "Refreshing PATH in current shell"
    Refresh-Path

    if (-not (Test-CommandExists "ffmpeg")) {
        throw "FFmpeg still not found. Reopen PowerShell and run the script again."
    }

    Write-Host "FFmpeg installed:" -ForegroundColor Green
    ffmpeg -version | Select-Object -First 1
}

function Ensure-Pip {
    if (-not (Test-CommandExists "python")) {
        throw "python not found, cannot continue."
    }

    Write-Step "Checking pip"
    python -m pip --version
}

function Install-WhisperDeps {
    Write-Step "Upgrading pip"
    python -m pip install --upgrade pip

    Write-Step "Installing faster-whisper"
    python -m pip install faster-whisper
}

try {
    Write-Host "Preparing environment: Python + FFmpeg + faster-whisper" -ForegroundColor Magenta

    Install-PythonIfNeeded
    Ensure-Pip
    Install-FFmpegIfNeeded
    Install-WhisperDeps

    Write-Host "`n==============================" -ForegroundColor Green
    Write-Host "Environment setup completed." -ForegroundColor Green
    Write-Host "Quick checks:" -ForegroundColor Green
    Write-Host "  python --version"
    Write-Host "  ffmpeg -version"
    Write-Host "  python -m pip show faster-whisper"
    Write-Host "==============================" -ForegroundColor Green
}
catch {
    Write-Host "`n[ERROR] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Please fix the error above and rerun this script."
    exit 1
}
