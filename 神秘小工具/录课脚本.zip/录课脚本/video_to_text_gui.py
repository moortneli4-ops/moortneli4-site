"""Desktop GUI: one-click video-to-text with audio/text preview."""

import subprocess
import sys
from pathlib import Path

from faster_whisper import WhisperModel
from PyQt5.QtCore import QThread, QUrl, pyqtSignal
from PyQt5.QtMultimedia import QMediaContent, QMediaPlayer
from PyQt5.QtWidgets import (
    QApplication,
    QFileDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
    QComboBox,
)


class TranscribeWorker(QThread):
    status_changed = pyqtSignal(str)
    failed = pyqtSignal(str)
    succeeded = pyqtSignal(str, str, str)

    def __init__(self, video_path: Path, model_size: str):
        super().__init__()
        self.video_path = video_path
        self.model_size = model_size

    def run(self):
        try:
            if not self.video_path.exists():
                raise FileNotFoundError(f"Input file not found: {self.video_path}")

            audio_path = self.video_path.with_suffix(".wav")
            self.status_changed.emit("Step 1/2: extracting audio with ffmpeg...")
            self._extract_audio(self.video_path, audio_path)

            self.status_changed.emit("Step 2/2: transcribing audio with faster-whisper...")
            text = self._transcribe_audio(audio_path)

            default_text_path = str(self.video_path.with_suffix(".txt"))
            self.succeeded.emit(str(audio_path), text, default_text_path)
        except Exception as exc:  # pylint: disable=broad-except
            self.failed.emit(str(exc))

    @staticmethod
    def _extract_audio(video_path: Path, audio_path: Path):
        cmd = [
            "ffmpeg",
            "-y",
            "-i",
            str(video_path),
            "-ac",
            "1",
            "-ar",
            "16000",
            str(audio_path),
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if result.returncode != 0:
            stderr = result.stderr.strip() or "ffmpeg failed with no stderr output."
            raise RuntimeError(
                "Audio extraction failed. Confirm ffmpeg is installed and in PATH.\n"
                f"Details: {stderr[-500:]}"
            )

    def _transcribe_audio(self, audio_path: Path) -> str:
        model = WhisperModel(self.model_size, device="cpu", compute_type="int8")
        segments, _ = model.transcribe(
            str(audio_path), language="zh", vad_filter=True, beam_size=5
        )

        lines = []
        for seg in segments:
            text = seg.text.strip()
            if text:
                lines.append(text)
        return "\n".join(lines)


class VideoToTextWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Video -> Text 一键转写工具")
        self.resize(980, 700)

        self.worker = None
        self.current_audio_path = None
        self.player = QMediaPlayer(self)

        self._build_ui()

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        main_layout = QVBoxLayout(root)

        file_group = QGroupBox("1) Select Video")
        file_layout = QGridLayout(file_group)
        self.video_path_input = QLineEdit()
        self.video_path_input.setPlaceholderText("Choose a video file (.mp4/.mkv/.mov/...)")
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self.choose_video)
        file_layout.addWidget(QLabel("Video path"), 0, 0)
        file_layout.addWidget(self.video_path_input, 0, 1)
        file_layout.addWidget(browse_btn, 0, 2)

        self.model_combo = QComboBox()
        self.model_combo.addItems(["small", "medium", "large-v3"])
        file_layout.addWidget(QLabel("Model"), 1, 0)
        file_layout.addWidget(self.model_combo, 1, 1)

        run_btn = QPushButton("One Click: Video -> Text")
        run_btn.clicked.connect(self.start_pipeline)
        self.run_btn = run_btn
        file_layout.addWidget(run_btn, 1, 2)

        self.status_label = QLabel("Status: waiting")
        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        file_layout.addWidget(self.status_label, 2, 0, 1, 3)
        file_layout.addWidget(self.progress, 3, 0, 1, 3)

        audio_group = QGroupBox("2) Audio Preview (intermediate WAV)")
        audio_layout = QHBoxLayout(audio_group)
        self.audio_path_label = QLabel("No extracted audio yet.")
        play_btn = QPushButton("Play")
        pause_btn = QPushButton("Pause")
        stop_btn = QPushButton("Stop")
        play_btn.clicked.connect(self.play_audio)
        pause_btn.clicked.connect(self.pause_audio)
        stop_btn.clicked.connect(self.stop_audio)
        audio_layout.addWidget(self.audio_path_label, 2)
        audio_layout.addWidget(play_btn)
        audio_layout.addWidget(pause_btn)
        audio_layout.addWidget(stop_btn)

        text_group = QGroupBox("3) Transcript Preview (editable)")
        text_layout = QVBoxLayout(text_group)
        self.text_preview = QTextEdit()
        self.text_preview.setPlaceholderText("Transcript will appear here...")
        text_layout.addWidget(self.text_preview)

        save_group = QGroupBox("4) Rename and Save Text")
        save_layout = QGridLayout(save_group)
        self.save_path_input = QLineEdit()
        self.save_path_input.setPlaceholderText("Default: same folder and same base name as video")
        save_browse_btn = QPushButton("Choose Save Path...")
        save_browse_btn.clicked.connect(self.choose_save_path)
        save_btn = QPushButton("Save Text")
        save_btn.clicked.connect(self.save_text)
        save_layout.addWidget(QLabel("Output txt"), 0, 0)
        save_layout.addWidget(self.save_path_input, 0, 1)
        save_layout.addWidget(save_browse_btn, 0, 2)
        save_layout.addWidget(save_btn, 0, 3)

        main_layout.addWidget(file_group)
        main_layout.addWidget(audio_group)
        main_layout.addWidget(text_group, 1)
        main_layout.addWidget(save_group)

    def choose_video(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Choose video",
            "",
            "Video files (*.mp4 *.mkv *.mov *.avi *.flv *.webm);;All files (*.*)",
        )
        if not path:
            return
        self.video_path_input.setText(path)
        default_save = str(Path(path).with_suffix(".txt"))
        self.save_path_input.setText(default_save)
        self.status_label.setText("Status: video selected")

    def choose_save_path(self):
        current = self.save_path_input.text().strip() or "transcript.txt"
        path, _ = QFileDialog.getSaveFileName(
            self, "Choose save path", current, "Text files (*.txt);;All files (*.*)"
        )
        if path:
            self.save_path_input.setText(path)

    def start_pipeline(self):
        raw_video_path = self.video_path_input.text().strip()
        if not raw_video_path:
            QMessageBox.warning(self, "Missing file", "Please choose a video file first.")
            return

        video_path = Path(raw_video_path)
        if not video_path.exists():
            QMessageBox.warning(self, "File not found", f"Video not found:\n{video_path}")
            return

        self.run_btn.setEnabled(False)
        self.progress.setRange(0, 0)
        self.status_label.setText("Status: running...")

        self.worker = TranscribeWorker(video_path, self.model_combo.currentText())
        self.worker.status_changed.connect(self.on_worker_status)
        self.worker.failed.connect(self.on_worker_failed)
        self.worker.succeeded.connect(self.on_worker_succeeded)
        self.worker.finished.connect(self.on_worker_finished)
        self.worker.start()

    def on_worker_status(self, msg: str):
        self.status_label.setText(f"Status: {msg}")

    def on_worker_failed(self, err: str):
        self.status_label.setText("Status: failed")
        QMessageBox.critical(self, "Pipeline failed", err)

    def on_worker_succeeded(self, audio_path: str, transcript_text: str, default_text_path: str):
        self.current_audio_path = audio_path
        self.audio_path_label.setText(audio_path)
        self.text_preview.setPlainText(transcript_text)

        if not self.save_path_input.text().strip():
            self.save_path_input.setText(default_text_path)

        self.status_label.setText("Status: done. You can preview and save.")
        QMessageBox.information(self, "Done", "Transcription complete. Please preview and click Save.")

    def on_worker_finished(self):
        self.run_btn.setEnabled(True)
        self.progress.setRange(0, 1)
        self.progress.setValue(0)

    def play_audio(self):
        if not self.current_audio_path:
            QMessageBox.information(self, "No audio", "Run transcription first to generate audio.")
            return
        audio_file = Path(self.current_audio_path)
        if not audio_file.exists():
            QMessageBox.warning(self, "Missing audio", f"Audio file not found:\n{audio_file}")
            return
        media = QMediaContent(QUrl.fromLocalFile(str(audio_file)))
        self.player.setMedia(media)
        self.player.play()

    def pause_audio(self):
        self.player.pause()

    def stop_audio(self):
        self.player.stop()

    def save_text(self):
        output = self.save_path_input.text().strip()
        if not output:
            QMessageBox.warning(self, "Missing path", "Please set an output txt path first.")
            return
        text = self.text_preview.toPlainText().strip()
        if not text:
            QMessageBox.warning(self, "No transcript", "Transcript is empty. Run transcription first.")
            return

        out_path = Path(output)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        if out_path.exists():
            choice = QMessageBox.question(
                self,
                "Overwrite?",
                f"File already exists:\n{out_path}\n\nOverwrite?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if choice != QMessageBox.Yes:
                return

        out_path.write_text(text + "\n", encoding="utf-8")
        QMessageBox.information(self, "Saved", f"Saved transcript:\n{out_path}")


def main():
    app = QApplication(sys.argv)
    win = VideoToTextWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
